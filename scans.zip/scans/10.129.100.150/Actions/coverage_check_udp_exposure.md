# Check UDP exposure

**Analyst status:** Auto

> Change Auto to Needs Action, In Progress, or Completed to override the generated status. An exit code of zero means the tool ran; it does not validate a vulnerability.

<!-- BEGIN GENERATED EVIDENCE -->
**Purpose:** No UDP discovery evidence recorded

**Recommended command / procedure:**

```bash
sudo bash ./NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh 10.129.100.150 UDP
```

**Execution status:** Not run

**Suggested workflow status:** Needs Action

**Result note:** Not collected

**Raw evidence:** Not collected

**Evidence source:** Coverage / triage
<!-- END GENERATED EVIDENCE -->

## Observations

- 

## Analyst validation notes

- 

## Follow-up / disposition

- 
