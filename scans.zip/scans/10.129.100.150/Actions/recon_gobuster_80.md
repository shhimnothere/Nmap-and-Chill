# Gobuster 80

**Analyst status:** Auto

> Change Auto to Needs Action, In Progress, or Completed to override the generated status. An exit code of zero means the tool ran; it does not validate a vulnerability.

<!-- BEGIN GENERATED EVIDENCE -->
**Purpose:** Execute or review service-specific reconnaissance (Deep web).

**Recommended command / procedure:**

```bash
gobuster dir -u http://10.129.100.150:80/ -w /usr/share/wordlists/dirb/common.txt -t 5 --timeout 10s
```

**Execution status:** EXIT=0 DURATION_SECONDS=29

**Suggested workflow status:** Completed

**Result note:** [Open Obsidian result](<../Runs/26-11-05_19-36-27_Recon/recon/gobuster_80.md>)

**Raw evidence:** [Open raw output](<../Runs/26-11-05_19-36-27_Recon/recon/gobuster_80.txt>)

**Evidence source:** Recon
<!-- END GENERATED EVIDENCE -->

## Observations

- 

## Analyst validation notes

- 

## Follow-up / disposition

- 
