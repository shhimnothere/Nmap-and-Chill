# Http Headers 80

**Analyst status:** Auto

> Change Auto to Needs Action, In Progress, or Completed to override the generated status. An exit code of zero means the tool ran; it does not validate a vulnerability.

<!-- BEGIN GENERATED EVIDENCE -->
**Purpose:** Execute or review service-specific reconnaissance (Standard).

**Recommended command / procedure:**

```bash
curl --head --max-time 15 -- http://10.129.100.150:80/
```

**Execution status:** EXIT=0 DURATION_SECONDS=0

**Suggested workflow status:** Completed

**Result note:** [Open Obsidian result](<../Runs/26-11-05_19-36-27_Recon/recon/http_headers_80.md>)

**Raw evidence:** [Open raw output](<../Runs/26-11-05_19-36-27_Recon/recon/http_headers_80.txt>)

**Evidence source:** Recon
<!-- END GENERATED EVIDENCE -->

## Observations

- 

## Analyst validation notes

- 

## Follow-up / disposition

- 
