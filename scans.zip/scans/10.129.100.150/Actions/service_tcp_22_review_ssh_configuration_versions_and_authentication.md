# tcp/22 — Review SSH configuration, versions, and authentication

**Analyst status:** Auto

> Change Auto to Needs Action, In Progress, or Completed to override the generated status. An exit code of zero means the tool ran; it does not validate a vulnerability.

<!-- BEGIN GENERATED EVIDENCE -->
**Purpose:** Analyst validation is required; an automated probe does not confirm security impact.

**Recommended command / procedure:**

```bash
Manual validation
```

**Execution status:** Not run

**Suggested workflow status:** Needs Action

**Result note:** Not collected

**Raw evidence:** Not collected

**Evidence source:** Service review
<!-- END GENERATED EVIDENCE -->

## Observations

- 

## Analyst validation notes

- 

## Follow-up / disposition

- 
