# 10.129.100.150 — Assessment Dashboard

> **Auto-generated evidence index.** Scanner observations are not validated vulnerabilities. Add analyst conclusions to [[01_FINDINGS]].

## At a glance

| Completed runs | Most recent | Latest broad TCP inventory | Observed TCP / UDP |
| ---: | --- | --- | ---: |
| 2 | Nov 05 19:35 (Full) | [26-11-05_19-33-26_Full](<Runs/26-11-05_19-33-26_Full/scan_summary.md>) | 2 / 0 |

**Modes recorded:** Basic, Full  
**Coverage note:** A count of zero UDP ports does **not** indicate a completed UDP assessment. Basic and Vulns use limited TCP discovery.

## Assessment workflow

> Action notes are persistent. Edit **Analyst status** in each note to move it between queues. Dashboard refreshes never erase analyst observations.

**Suggested scans and probes are tracked below; no network activity occurs when opening or refreshing this dashboard.**

**Reuse:** Existing scan evidence is reused when the mode and scope match. Use `--fresh` for a new measurement.

**Saved recon commands:** [View recommendations](<Runs/26-11-05_19-36-27_Recon/recon/recommendations.txt>) (no need to rerun discovery).

### Recon action plan and saved results

> Commands below are for authorized assessments only. They are not executed by opening Obsidian. Run the scanner command shown below to capture their outputs.

**Run saved recommendations:** `sudo bash ./NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh 10.129.100.150 Recon --run-recon --web-deep`

**Without deeper web checks:** `sudo bash ./NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh 10.129.100.150 Recon --run-recon`

**Refresh this page without network traffic:** `bash ./NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh 10.129.100.150 Dashboard`

**Recommendation source:** [Saved commands](<Runs/26-11-05_19-36-27_Recon/recon/recommendations.txt>)

| Action | Scope | Status | Saved evidence |
| --- | --- | --- | --- |
| `http_headers_80` | Standard | EXIT=0 DURATION_SECONDS=0 | [Obsidian note](<Runs/26-11-05_19-36-27_Recon/recon/http_headers_80.md>) |
| `nikto_80` | Deep web | EXIT=0 DURATION_SECONDS=275 | [Obsidian note](<Runs/26-11-05_19-36-27_Recon/recon/nikto_80.md>) |
| `gobuster_80` | Deep web | EXIT=0 DURATION_SECONDS=29 | [Obsidian note](<Runs/26-11-05_19-36-27_Recon/recon/gobuster_80.md>) |

**Commands to run or review:**

- **http_headers_80** — `curl --head --max-time 15 -- http://10.129.100.150:80/`

- **nikto_80** — `nikto -host http://10.129.100.150:80/ -timeout 10`

- **gobuster_80** — `gobuster dir -u http://10.129.100.150:80/ -w /usr/share/wordlists/dirb/common.txt -t 5 --timeout 10s`

### Executed reconnaissance history

| Run | Probe | Result note |
| --- | --- | --- |
| Nov 05 19:41 | gobuster_80 | [Open result](<Runs/26-11-05_19-36-27_Recon/recon/gobuster_80.md>) |
| Nov 05 19:41 | http_headers_80 | [Open result](<Runs/26-11-05_19-36-27_Recon/recon/http_headers_80.md>) |
| Nov 05 19:41 | nikto_80 | [Open result](<Runs/26-11-05_19-36-27_Recon/recon/nikto_80.md>) |

### Needs Action → In Progress → Completed

Each action has a permanent note in `Actions/` with purpose, command, execution status, evidence links, observations, and editable analyst notes. Edit **Analyst status** in a note and refresh the dashboard to move it. `Auto` follows probe execution.

#### Needs Action (4)

| Action | Evidence / status | Action note |
| --- | --- | --- |
| Check UDP exposure | Not run / manual review | [Open action note](<Actions/coverage_check_udp_exposure.md>) |
| Run vulnerability checks | Not run / manual review | [Open action note](<Actions/coverage_run_vulnerability_checks.md>) |
| tcp/22 — Review SSH configuration, versions, and authentication | Not run / manual review | [Open action note](<Actions/service_tcp_22_review_ssh_configuration_versions_and_authentication.md>) |
| tcp/80 — Inspect HTTP headers, authentication, and application routes | Not run / manual review | [Open action note](<Actions/service_tcp_80_inspect_http_headers_authentication_and_application_routes.md>) |

#### In Progress (0)

| Action | Evidence / status | Action note |
| --- | --- | --- |
| — | — | — |

#### Completed (5)

| Action | Evidence / status | Action note |
| --- | --- | --- |
| Full TCP port coverage | Historical / review for relevance | [Open action note](<Actions/coverage_full_tcp_port_coverage.md>) |
| Generate service-specific recon actions | Historical / review for relevance | [Open action note](<Actions/coverage_generate_service-specific_recon_actions.md>) |
| Gobuster 80 | Probe completed; validation may remain | [Open action note](<Actions/recon_gobuster_80.md>) |
| Http Headers 80 | Probe completed; validation may remain | [Open action note](<Actions/recon_http_headers_80.md>) |
| Nikto 80 | Probe completed; validation may remain | [Open action note](<Actions/recon_nikto_80.md>) |

**Tracked recommendations:** 9 · Needs Action 4 · In Progress 0 · Completed 5

## Service inventory

**Inventory source:** [26-11-05_19-33-26_Full](<Runs/26-11-05_19-33-26_Full/scan_summary.md>) (Full). This is one selected scan, not a union of historical ports.

| Protocol/port | Service / version | Readable report |
| --- | --- | --- |
| tcp/22 | ssh OpenSSH 8.2p1 Ubuntu 4ubuntu0.3 Ubuntu Linux; protocol 2.0 | [HTML](<Runs/26-11-05_19-33-26_Full/nmap/full_services.html>) |
| tcp/80 | http Apache httpd 2.4.41 (Ubuntu) | [HTML](<Runs/26-11-05_19-33-26_Full/nmap/full_services.html>) |

## Potential vulnerability references (unverified)

No completed Vulners NSE output with parseable CVE/score entries yet. This does not mean no vulnerabilities exist.

## Changes between comparable scans

No previous completed **Full** scan to compare with the latest run. Different scan types are not treated as equivalent coverage.

## Scan timeline

| Local time | Scan | Status | Observed TCP / UDP | Evidence |
| --- | --- | --- | ---: | --- |
| Nov 05 19:41 | Recon (default) | Completed | 0 / 0 | [26-11-05_19-36-27_Recon](<Runs/26-11-05_19-36-27_Recon/scan_summary.md>) |
| Nov 05 19:36 | Recon (default) | Completed | 0 / 0 | [26-11-05_19-36-11_Recon](<Runs/26-11-05_19-36-11_Recon/scan_summary.md>) |
| Nov 05 19:35 | Full (default) | Completed | 2 / 0 | [26-11-05_19-33-26_Full](<Runs/26-11-05_19-33-26_Full/scan_summary.md>) |
| Nov 05 19:33 | Basic (default) | Completed | 2 / 0 | [26-11-05_19-33-01_Basic](<Runs/26-11-05_19-33-01_Basic/scan_summary.md>) |

## Analyst workspace

- [[01_FINDINGS|Validated findings and retest notes]]
- Scan artifacts remain inside `Runs/` (HTML reports and Markdown notes in `nmap/`, original XML in `nmap/xml/`, plus GNMAP, logs, and recon evidence).
- Legacy scan folders remain in place and are linked when detected.

