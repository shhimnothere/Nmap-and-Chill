# Full Services — 10.129.100.150

**Original evidence:** [full_services.nmap](<full_services.nmap>) | [XML](<xml/full_services.xml>) | [GNMAP](<full_services.gnmap>) | [HTML report](<full_services.html>)

~~~~text
# Nmap 7.991 scan initiated Thu Nov  5 19:35:41 2026 as: /usr/lib/nmap/nmap -sC -sV -p 22,80 -oA ./scans/10.129.100.150/Runs/26-11-05_19-33-26_Full/nmap/full_services 10.129.100.150
Nmap scan report for 10.129.100.150
Host is up (0.028s latency).

PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 8.2p1 Ubuntu 4ubuntu0.3 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey: 
|   3072 24:c2:95:a5:c3:0b:3f:f3:17:3c:68:d7:af:2b:53:38 (RSA)
|   256 b1:41:77:99:46:9a:6c:5d:d2:98:2f:c0:32:9a:ce:03 (ECDSA)
|_  256 e7:36:43:3b:a9:47:8a:19:01:58:b2:bc:89:f6:51:08 (ED25519)
80/tcp open  http    Apache httpd 2.4.41 ((Ubuntu))
|_http-title: Play | Landing
|_http-server-header: Apache/2.4.41 (Ubuntu)
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
# Nmap done at Thu Nov  5 19:35:51 2026 -- 1 IP address (1 host up) scanned in 10.06 seconds
~~~~
