# Full Discovery — 10.129.100.150

**Original evidence:** [full_discovery.nmap](<full_discovery.nmap>) | [XML](<xml/full_discovery.xml>) | [GNMAP](<full_discovery.gnmap>) | [HTML report](<full_discovery.html>)

~~~~text
# Nmap 7.991 scan initiated Thu Nov  5 19:33:26 2026 as: /usr/lib/nmap/nmap -p- -T4 --max-retries 1 --max-rate 500 -oA ./scans/10.129.100.150/Runs/26-11-05_19-33-26_Full/nmap/full_discovery 10.129.100.150
Warning: 10.129.100.150 giving up on port because retransmission cap hit (1).
Nmap scan report for 10.129.100.150
Host is up (0.027s latency).
Not shown: 65430 closed tcp ports (reset), 103 filtered tcp ports (no-response)
PORT   STATE SERVICE
22/tcp open  ssh
80/tcp open  http

# Nmap done at Thu Nov  5 19:35:41 2026 -- 1 IP address (1 host up) scanned in 134.80 seconds
~~~~
