# Recon result: nikto 80

**Target:** 10.129.100.150

**Status:** `EXIT=0 DURATION_SECONDS=275`

**Original evidence:** [nikto_80.txt](<nikto_80.txt>)

~~~~text
Target: 10.129.100.150
Probe: nikto_80
UTC: 2026-11-06T00:36:27Z
Command: nikto -host http://10.129.100.150:80/ -timeout 10 -nointeractive 

- Nikto v2.6.1
---------------------------------------------------------------------------
+ Target IP:          10.129.100.150
+ Target Hostname:    10.129.100.150
+ Target Port:        80
+ Platform:           Unknown
+ Start Time:         2026-11-05 19:36:28 (GMT-5)
---------------------------------------------------------------------------
+ Server: Apache/2.4.41 (Ubuntu)
+ No CGI Directories found (use '-C all' to force check all possible dirs). CGI tests skipped.
+ [999990] OPTIONS: Allowed HTTP Methods: OPTIONS, HEAD, GET, POST .
+ [600050] Apache/2.4.41 appears to be outdated (current is at least 2.4.68).
+ [013587] /: Suggested security header missing: content-security-policy. See: https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP
+ [013587] /: Suggested security header missing: referrer-policy. See: https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referrer-Policy
+ [013587] /: Suggested security header missing: strict-transport-security. See: https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Strict-Transport-Security
+ [013587] /: Suggested security header missing: permissions-policy. See: https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Permissions-Policy
+ [013587] /: Suggested security header missing: x-content-type-options. See: https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-Content-Type-Options
+ [007342] /: X-Frame-Options header is deprecated and was replaced with the Content-Security-Policy HTTP header with the frame-ancestors directive. See: https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/X-Frame-Options
+ [007352] /: The X-Content-Type-Options header is not set. This could allow the user agent to render the content of the site in a different fashion to the MIME type. See: https://www.netsparker.com/web-vulnerability-scanner/vulnerabilities/missing-content-type-header/
+ 8276 requests: 0 errors and 9 items reported on the remote host
+ End Time:           2026-11-05 19:41:02 (GMT-5) (274 seconds)
---------------------------------------------------------------------------
+ 1 host(s) tested
Probe result: nikto_80 | EXIT=0 | DURATION_SECONDS=275 | Raw evidence: ./scans/10.129.100.150/Runs/26-11-05_19-36-27_Recon/recon/nikto_80.txt
~~~~
