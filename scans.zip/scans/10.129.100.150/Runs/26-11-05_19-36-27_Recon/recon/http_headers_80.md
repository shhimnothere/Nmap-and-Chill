# Recon result: http headers 80

**Target:** 10.129.100.150

**Status:** `EXIT=0 DURATION_SECONDS=0`

**Original evidence:** [http_headers_80.txt](<http_headers_80.txt>)

~~~~text
Target: 10.129.100.150
Probe: http_headers_80
UTC: 2026-11-06T00:36:27Z
Command: curl --silent --show-error --head --connect-timeout 5 --max-time 15 -- http://10.129.100.150:80/ 

HTTP/1.1 200 OK
Date: Fri, 06 Nov 2026 00:36:22 GMT
Server: Apache/2.4.41 (Ubuntu)
Last-Modified: Fri, 03 Dec 2021 14:00:31 GMT
ETag: "8318-5d23e548bc656"
Accept-Ranges: bytes
Content-Length: 33560
Vary: Accept-Encoding
Content-Type: text/html

Probe result: http_headers_80 | EXIT=0 | DURATION_SECONDS=0 | Raw evidence: ./scans/10.129.100.150/Runs/26-11-05_19-36-27_Recon/recon/http_headers_80.txt
~~~~
