# Recon result: gobuster 80

**Target:** 10.129.100.150

**Status:** `EXIT=0 DURATION_SECONDS=29`

**Original evidence:** [gobuster_80.txt](<gobuster_80.txt>)

~~~~text
Target: 10.129.100.150
Probe: gobuster_80
UTC: 2026-11-06T00:41:02Z
Command: gobuster dir -u http://10.129.100.150:80/ -w /usr/share/wordlists/dirb/common.txt -t 5 --timeout 10s -q -k 

.hta                 (Status: 403) [Size: 279]
.htaccess            (Status: 403) [Size: 279]
.htpasswd            (Status: 403) [Size: 279]
assets               (Status: 301) [Size: 317] [--> http://10.129.100.150/assets/]
index.html           (Status: 200) [Size: 33560]
server-status        (Status: 403) [Size: 279]
Probe result: gobuster_80 | EXIT=0 | DURATION_SECONDS=29 | Raw evidence: ./scans/10.129.100.150/Runs/26-11-05_19-36-27_Recon/recon/gobuster_80.txt
~~~~
