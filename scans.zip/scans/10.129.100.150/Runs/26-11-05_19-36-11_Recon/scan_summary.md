# Nmap assessment — 10.129.100.150

**Scan mode:** recon
**Port scope / tuning:** default
**UTC generated:** 2026-11-06 00:36:11
**Reported scan/probe failures:** 0

## Discovered ports and services

| Protocol | Port | State | Service | Product / Version | Evidence |
| --- | ---: | --- | --- | --- | --- |
| — | — | No confirmed-open ports parsed | — | — | — |

## Available scan evidence


## Recon recommendations

[View recommended actions](<recon/02_RECOMMENDED_ACTIONS.md>)


## Executed follow-up reconnaissance

> Tool output is an observation; manually validate security findings.

- [02 RECOMMENDED ACTIONS](<recon/02_RECOMMENDED_ACTIONS.md>) — `status unavailable`

## Analyst notes

- 

## Findings to validate

- 
