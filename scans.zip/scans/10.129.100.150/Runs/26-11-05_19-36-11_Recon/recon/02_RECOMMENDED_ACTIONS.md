# Recommended recon actions — 10.129.100.150

**Original commands:** [recommendations.txt](<recommendations.txt>)

> Commands are suggestions, not automatically validated findings.

```bash
# Suggested follow-up for 10.129.100.150
# Confirmed TCP: 22,80 | UDP: none
# Use --run-recon to perform supported probes; add --web-deep for content discovery.
curl --head --max-time 15 -- http://10.129.100.150:80/
nikto -host http://10.129.100.150:80/ -timeout 10
gobuster dir -u http://10.129.100.150:80/ -w /usr/share/wordlists/dirb/common.txt -t 5 --timeout 10s
```
