# Quick — 10.129.100.150

**Original evidence:** [quick.nmap](<quick.nmap>) | [XML](<xml/quick.xml>) | [GNMAP](<quick.gnmap>) | [HTML report](<quick.html>)

~~~~text
# Nmap 7.991 scan initiated Thu Nov  5 19:33:01 2026 as: /usr/lib/nmap/nmap -T4 --max-retries 1 --open -oA ./scans/10.129.100.150/Runs/26-11-05_19-33-01_Basic/nmap/quick 10.129.100.150
Nmap scan report for 10.129.100.150
Host is up (0.027s latency).
Not shown: 998 closed tcp ports (reset)
PORT   STATE SERVICE
22/tcp open  ssh
80/tcp open  http

# Nmap done at Thu Nov  5 19:33:04 2026 -- 1 IP address (1 host up) scanned in 3.19 seconds
~~~~
