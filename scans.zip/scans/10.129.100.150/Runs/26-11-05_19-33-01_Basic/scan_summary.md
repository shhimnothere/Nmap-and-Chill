# Nmap assessment — 10.129.100.150

**Scan mode:** basic
**Port scope / tuning:** default
**UTC generated:** 2026-11-06 00:33:14
**Reported scan/probe failures:** 0

## Discovered ports and services

| Protocol | Port | State | Service | Product / Version | Evidence |
| --- | ---: | --- | --- | --- | --- |
| tcp | 22 | open | ssh | OpenSSH 8.2p1 Ubuntu 4ubuntu0.3 Ubuntu Linux; protocol 2.0 | [HTML](<nmap/basic.html>) |
| tcp | 22 | open | ssh |  | [HTML](<nmap/quick.html>) |
| tcp | 80 | open | http | Apache httpd 2.4.41 (Ubuntu) | [HTML](<nmap/basic.html>) |
| tcp | 80 | open | http |  | [HTML](<nmap/quick.html>) |

## Available scan evidence

- [basic — readable output](<nmap/basic.md>)
- [quick — readable output](<nmap/quick.md>)
- [basic.xml — original XML](<nmap/xml/basic.xml>)
- [quick.xml — original XML](<nmap/xml/quick.xml>)
- [basic.html — rendered HTML report](<nmap/basic.html>)
- [quick.html — rendered HTML report](<nmap/quick.html>)

## NSE script output

> Raw script observations are not automatically validated vulnerabilities.

### ssh-hostkey (tcp/22, basic)

~~~~text
3072 24:c2:95:a5:c3:0b:3f:f3:17:3c:68:d7:af:2b:53:38 (RSA)
  256 b1:41:77:99:46:9a:6c:5d:d2:98:2f:c0:32:9a:ce:03 (ECDSA)
  256 e7:36:43:3b:a9:47:8a:19:01:58:b2:bc:89:f6:51:08 (ED25519)
~~~~

### http-server-header (tcp/80, basic)

~~~~text
Apache/2.4.41 (Ubuntu)
~~~~

### http-title (tcp/80, basic)

~~~~text
Play | Landing
~~~~


## Analyst notes

- 

## Findings to validate

- 
