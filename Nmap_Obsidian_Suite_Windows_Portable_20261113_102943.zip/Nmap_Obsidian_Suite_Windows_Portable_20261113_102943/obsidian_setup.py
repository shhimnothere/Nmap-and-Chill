"""Configure scan vault viewers from locally bundled plugin installations."""
import json
import pathlib
import shutil
import subprocess
import os

PLUGINS = ('html-page-viewer', 'xml-viewer', 'just-simple-file-viewer')
ASSETS = pathlib.Path(__file__).resolve().parent / 'obsidian_plugins'


def read_json(path, default):
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default


def write_json(path, value):
    text = json.dumps(value, indent=2) + '\n'
    if not path.exists() or path.read_text(encoding='utf-8') != text:
        path.write_text(text, encoding='utf-8')


def configure_vault(vault):
    config = pathlib.Path(vault) / '.obsidian'
    config.mkdir(parents=True, exist_ok=True)
    app = read_json(config / 'app.json', {})
    app['showUnsupportedFiles'] = True
    app.setdefault('alwaysUpdateLinks', True)
    write_json(config / 'app.json', app)
    enabled = read_json(config / 'community-plugins.json', [])
    for plugin in PLUGINS:
        source = ASSETS / plugin
        dest = config / 'plugins' / plugin
        dest.mkdir(parents=True, exist_ok=True)
        for name in ('manifest.json', 'main.js', 'styles.css'):
            if (source / name).exists() and not (dest / name).exists():
                shutil.copy2(source / name, dest / name)
        if not (dest / 'main.js').exists() or not (dest / 'manifest.json').exists():
            raise RuntimeError('Missing bundled Obsidian plugin: ' + plugin)
        if plugin not in enabled:
            enabled.append(plugin)
    write_json(config / 'community-plugins.json', enabled)
    data_path = config / 'plugins' / 'just-simple-file-viewer' / 'data.json'
    data = read_json(data_path, {})
    extensions = [x.strip().lstrip('.') for x in data.get('extensions', '').split(',') if x.strip()]
    for ext in ('txt', 'nmap', 'gnmap', 'log', 'out', 'ansi'):
        if ext not in extensions:
            extensions.append(ext)
    data['extensions'] = ','.join(extensions)
    write_json(data_path, data)


def enable_viewers(vault_name):
    """Apply trust through Obsidian's own CLI, rather than an unsupported JSON flag."""
    cli = shutil.which('obsidian')
    if os.name == 'nt':
        candidate = pathlib.Path.home() / 'AppData/Local/Programs/Obsidian/Obsidian.com'
        if candidate.exists():
            cli = str(candidate)
    if not cli:
        raise RuntimeError('Obsidian CLI unavailable; enable community plugins in Obsidian settings.')
    if pathlib.Path(vault_name).is_absolute():
        config_path = pathlib.Path.home() / 'AppData/Roaming/obsidian/obsidian.json' if os.name == 'nt' else pathlib.Path.home() / '.config/obsidian/obsidian.json'
        for vault_id, info in read_json(config_path, {}).get('vaults', {}).items():
            if pathlib.Path(info.get('path', '')).resolve() == pathlib.Path(vault_name).resolve():
                vault_name = vault_id
                break
    code = "(async()=>{await app.plugins.setEnable(true);await app.plugins.loadManifests();"
    for plugin in PLUGINS:
        code += 'await app.plugins.enablePluginAndSave(' + json.dumps(plugin) + ');'
    code += "app.vault.setConfig('showUnsupportedFiles',true);return 'Scan viewers enabled';})()"
    import time
    for attempt in range(4):
        result = subprocess.run([cli, 'vault=' + vault_name, 'eval', 'code=' + code],
        capture_output=True, text=True, timeout=40,
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        if result.returncode == 0 and 'Scan viewers enabled' in result.stdout:
            return
        time.sleep(2)
    raise RuntimeError((result.stdout + result.stderr).strip() or 'Unable to enable Obsidian viewers')
