"""Evidence-derived test history and gated next-step selection. Never executes tests."""
from __future__ import annotations
import json
import pathlib
import re
import xml.etree.ElementTree as ET
from urllib.parse import quote


def safe_files(root):
    for path in root.rglob('*'):
        if any(x in path.parts for x in ('imports', '.restricted', '.obsidian')):
            continue
        if path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(root):
            yield path


def read(path, limit=2_000_000):
    if path.stat().st_size > limit:
        raise ValueError('Evidence exceeds parser limit')
    return path.read_text(encoding='utf-8-sig', errors='replace')


def read_json(path, default):
    try:
        return json.loads(read(path)) if path.exists() else default
    except (ValueError, OSError):
        return default


def discover_targets(session):
    root=pathlib.Path(session).resolve()
    return sorted(p.name for p in root.iterdir() if p.is_dir() and not p.is_symlink() and p.name not in ('reports', 'subnets', 'Actions') and not p.name.startswith('.') and ((p/'Runs').exists() or (p/'evidence').exists() or (p/'00_TARGET_DASHBOARD.md').exists()))


def checked(text):
    check=re.search(r'^- \[([xX ])\] Completed <!-- action-completion -->',text,re.M)
    if check:
        return check.group(1).lower()=='x'
    return bool(re.search(r'^\*\*Analyst status:\*\*\s*Completed\s*$',text,re.M|re.I))


def build_history(session, target):
    root=pathlib.Path(session).resolve()
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,252}',target) or target in ('.','..'):
        raise ValueError('Choose one valid evidence target')
    host=root/target
    if host.is_symlink() or not host.resolve().is_relative_to(root) or not host.is_dir():
        raise ValueError('No evidence directory for selected target: '+target)
    history=dict(target=target,completed={},attempts=[],services=[],recon={},actions=[],local_findings=[],warnings=[],snmp=dict(data_sources=[],versions=[],community_reads=[],sensitive_sources=[],v3_advertised=False))
    def rel(path):return path.relative_to(host).as_posix()
    def completed(key,path):
        history['completed'].setdefault(key,[])
        if rel(path) not in history['completed'][key]:history['completed'][key].append(rel(path))
    files=sorted(safe_files(host))
    for path in files:
        if path.suffix.lower()!='.xml' or 'nmap' not in path.parts:
            continue
        try:
            text=read(path,12_000_000)
            if re.search(r'<!ENTITY\b',text,re.I) or re.search(r'<!DOCTYPE\s+[^>]*(?:SYSTEM|PUBLIC|\[)',text,re.I):
                raise ValueError('Unsafe XML declaration')
            tree=ET.fromstring(text)
            finished=tree.find('runstats/finished')
            matching=[node for node in tree.findall('host') if any(a.get('addr')==target for a in node.findall('address')) or any(n.get('name','').lower()==target.lower() for n in node.findall('hostnames/hostname'))]
            if not matching:
                history['warnings'].append(rel(path)+': target identity missing or different; not used')
                continue
            success=finished is not None and finished.get('exit')=='success'
            run=path.parent.parent if path.parent.name=='xml' else path.parent
            metadata=read_json(run.parent/'.scan_status.json',{})
            dry=bool(metadata.get('dry_run')) or metadata.get('mode','').lower()=='dry-run'
            history['attempts'].append(dict(source=rel(path),success=success and not dry,mode=metadata.get('mode','Unknown'),scope=metadata.get('scope','Unknown'),finished_at=finished.get('timestr') if finished is not None else None))
            if not success or dry:
                continue
            scaninfo=tree.findall('scaninfo')
            tcp=any(n.get('protocol')=='tcp' for n in scaninfo)
            udp=any(n.get('protocol')=='udp' for n in scaninfo)
            if tcp:completed('tcp_discovery',path)
            if udp:completed('udp_discovery',path)
            if any(n.get('protocol')=='tcp' and n.get('services')=='1-65535' and n.get('numservices')=='65535' for n in scaninfo):completed('full_tcp',path)
            if path.stem in ('basic','full_services','udp_services'):
                completed('udp_versions' if udp else 'service_versions',path)
            if path.stem in ('vuln_nse','vuln_cves'):completed('vuln_checks',path)
            for node in matching:
                for port in node.findall('ports/port'):
                    if port.find('state') is None or port.find('state').get('state')!='open':continue
                    service=port.find('service')
                    entry=dict(protocol=port.get('protocol'),port=port.get('portid'),name=service.get('name','unknown') if service is not None else 'unknown',source=rel(path))
                    if service is not None:
                        entry['product']=service.get('product','')
                        entry['version']=service.get('version','')
                    if entry not in history['services']:history['services'].append(entry)
                    if port.get('protocol')=='udp' and port.get('portid')=='161':
                        snmp=history['snmp']
                        product=service.get('product','') if service is not None else ''
                        if 'snmpv1' in product.lower():
                            snmp['versions'].append(dict(version='1',source=rel(path),status='Service identification; independent version probe provenance may be missing'))
                        snmp['v3_advertised'] |= 'snmpv3' in product.lower()
                        for script in port.findall('script'):
                            output=script.get('output','')
                            if script.get('id') in ('snmp-sysdescr','snmp-processes','snmp-interfaces','snmp-netstat') and output.strip():
                                if rel(path) not in snmp['data_sources']:snmp['data_sources'].append(rel(path))
                            # Never copy process arguments or credentials into the planning state.
                            if script.get('id')=='snmp-processes' and re.search(r'(?i)(?:password|passwd|secret|token|(?:^|\s)-[pP](?:\s|=))',output):
                                snmp['sensitive_sources'].append(rel(path))
        except (OSError,ValueError,ET.ParseError) as exc:
            history['warnings'].append(rel(path)+': '+str(exc))
    for path in files:
        if path.suffix=='.status' and path.parent.name=='recon':
            text=read(path,64000)
            raw=path.with_suffix('.txt')
            status='Completed' if re.search(r'\bEXIT=0\b',text) and raw.exists() and not re.search(r'UNVERIFIED|SKIPPED',text,re.I) else ('Skipped' if 'SKIPPED' in text else 'Failed or incomplete')
            previous=history['recon'].get(path.stem)
            # A later failed attempt cannot erase existing successful measurement evidence.
            if not previous or status=='Completed' or previous['status']!='Completed':
                history['recon'][path.stem]=dict(status=status,source=rel(path),raw_source=rel(raw) if raw.exists() else None,reason='Wordlist missing' if 'wordlist-missing' in text else status)
            if status=='Completed':completed('recon:'+path.stem,raw)
        if path.parent.name=='Actions' and path.suffix=='.md':
            text=read(path)
            title=text.splitlines()[0].lstrip('# ') if text else path.stem
            in_progress=bool(re.search(r'^\*\*Analyst status:\*\*\s*In Progress',text,re.M|re.I))
            history['actions'].append(dict(id=path.stem,title=title,source=rel(path),review_complete=checked(text),status='Completed' if checked(text) else ('In Progress' if in_progress else 'Needs Action')))
        # Include manually saved SNMP output independently of the generated action queue.
        if 'snmp' in path.as_posix().lower() and path.suffix.lower() in ('.md','.txt','.log','.out') and 'Actions' not in path.parts and path.name not in ('01_FINDINGS.md','00_TARGET_DASHBOARD.md'):
            try:
                text=read(path)
                command=re.search(r'(?im)^.*?\bsnmp(?:walk|get|bulkwalk)\b[^\r\n]*',text.replace('\\\n',' '))
                output=bool(re.search(r'(?m)(?:[\w.-]+::[\w.-]+|(?:\.\d+){4,}|\biso(?:\.\d+){3,})\s*=\s*(?:STRING|INTEGER|OID|Timeticks|Gauge32|Counter\d*|Hex-STRING)',text))
                if output:
                    if rel(path) not in history['snmp']['data_sources']:history['snmp']['data_sources'].append(rel(path))
                    if command and re.search(r'(?<![\d.])'+re.escape(target)+r'(?![\d.])',command.group()):
                        version=re.search(r'-v\s*(1|2c|3)\b',command.group())
                        if version:history['snmp']['versions'].append(dict(version=version.group(1),source=rel(path),status='Explicit command with returned OID values'))
                        if re.search(r'-c\s+[\"\x27]?public\b',command.group()):
                            history['snmp']['community_reads'].append(dict(community='public',version=version.group(1) if version else 'Unknown',source=rel(path),status='Command and returned OID values recorded; analyst should verify provenance'))
                    if re.search(r'(?i)(?:password|passwd|secret|token|(?:^|\s)-[pP](?:\s|=))',text):history['snmp']['sensitive_sources'].append(rel(path))
            except (ValueError,OSError) as exc:history['warnings'].append(rel(path)+': '+str(exc))
    db=read_json(host/'evidence/peas/parsed_findings.json',{})
    for f in db.get('findings',[]):
        page=host/'reports/peas'/(f['id']+'.md')
        text=read(page) if page.is_file() else ''
        match=re.search(r'^\*\*Validation:\*\*\s*([^\n]+)',text,re.M)
        status=match.group(1).strip() if match else f.get('validation_status','Needs Action')
        history['local_findings'].append(dict(id=f['id'],title=f['title'],status=status,severity=f['severity'],source=rel(page)))
    return history


def remaining_tasks(history):
    done=history['completed']
    services=history['services']
    tasks=[]
    def add(ident,title,purpose,procedure,sources,priority=3,mode='Manual review',settings='Use the existing evidence; no new scan required.'):
        tasks.append(dict(id=ident,title=title,purpose=purpose,procedure=procedure,sources=list(dict.fromkeys(sources)),priority=priority,mode=mode,settings=settings))
    def reviewed(part):return any(part in a['id'] and a['review_complete'] for a in history['actions'])
    if 'tcp_discovery' not in done:
        add('collect_tcp','Collect initial TCP evidence','Network discovery has no successful saved measurement.','Run Quick once against this target.',[],2,'Quick','Port Scope: Default; Speed Profile: Balanced; Dry-Run: off.')
    elif 'service_versions' not in done and not reviewed('identify_services_and_versions'):
        add('collect_versions','Collect service versions','Open TCP ports lack a successful service-probe result.','Run Basic on discovered open ports.',done['tcp_discovery'],2,'Basic','Port Scope: Default; Speed Profile: Balanced; Dry-Run: off.')
    if 'tcp_discovery' in done and 'full_tcp' not in done and not reviewed('full_tcp_port_coverage'):
        add('collect_full_tcp','Complete full TCP coverage','No successful XML establishes all 65,535 TCP ports.','Run Full with default all-port scope.',done['tcp_discovery'],4,'Full','Port Scope: Default; Speed Profile: Balanced; Dry-Run: off.')
    if 'udp_discovery' not in done and not reviewed('check_udp_exposure'):
        add('collect_udp','Assess UDP exposure','No successful saved UDP discovery exists.','Run UDP if included in the test scope.',[],5,'UDP','Port Scope: Default; WSL Root Mode: on; Speed Profile: Balanced; Dry-Run: off.')
    snmp=history['snmp']
    if snmp['data_sources'] and not reviewed('service_udp_161'):
        add('review_snmp_disclosure','Validate and document the existing SNMP disclosure','SNMP OID values were already collected. Review their access-control and information-disclosure implications rather than repeat the same walk.','Review the saved OID/process evidence, redact potential secrets, verify acquisition context, document SNMP version and actual community-read access, and assess management ACLs. Do not reuse credentials.',snmp['data_sources']+snmp['sensitive_sources'],1)
    elif any(s['protocol']=='udp' and s['port']=='161' for s in services) and not snmp['data_sources'] and not reviewed('service_udp_161'):
        add('validate_snmp_read','Validate SNMP read access','An open SNMP port or service banner alone does not prove community read access.','Use explicitly authorized read-only queries, independently recording v1/v2c results and the configured community; do not infer a v3 username from a community string.',[s['source'] for s in services if s['port']=='161'],2,'Manual test','Use only authorized communities and target; save command and raw output.')
    measured_versions={item['version'] for item in snmp['versions'] if item['status']=='Explicit command with returned OID values'}
    for version, other in (('1','2c'),('2c','1')):
        if snmp['data_sources'] and other in measured_versions and version not in measured_versions and not reviewed('service_udp_161'):
            add('validate_snmp_v'+version,'Validate the separate SNMPv'+version+' protocol gap','SNMPv'+other+' read evidence exists, but it does not independently establish SNMPv'+version+' support. This is a different protocol validation, not a repeat of the saved walk.','If authorized, collect a bounded read-only v'+version+' response using the approved community and record the exact version, target and result. Do not repeat v'+other+', test writes, guess usernames or reuse exposed credentials.',snmp['data_sources'],2,'Manual test','Use the same authorized target and approved read-only scope; record a v'+version+'-specific result. SNMPv3 authPriv requires separate configuration evidence.')
    for name,result in history['recon'].items():
        if result['status']=='Skipped' and not reviewed('recon_'+name):
            add('resolve_'+name,'Resolve skipped '+name.replace('_',' '),'The probe was skipped, not completed: '+result['reason'], 'Resolve the recorded prerequisite and run only this probe, preserving its output. If using the dashboard Recon mode, it may repeat other enabled probes; prefer a targeted manual test when appropriate.',[result['source']],3,'Manual test')
    coverage_map={'full_tcp_port_coverage':'full_tcp','identify_services_and_versions':'service_versions','check_udp_exposure':'udp_discovery','run_vulnerability_checks':'vuln_checks'}
    for action in history['actions']:
        if action['review_complete']:continue
        if any(fragment in action['id'] for fragment in coverage_map):continue
        if 'service_udp_161' in action['id']:continue
        if action['id'].startswith('recon_'):continue
        if 'generate_service-specific' in action['id'] and history['recon']:continue
        title=action['title']
        sources=[action['source']]
        if 'service_tcp_80' in action['id']:
            sources += [r['raw_source'] for key,r in history['recon'].items() if r['status']=='Completed' and any(t in key for t in ('http','nikto')) and r['raw_source']]
        if 'service_tcp_22' in action['id']:
            sources += [r['raw_source'] for key,r in history['recon'].items() if r['status']=='Completed' and 'ssh' in key and r['raw_source']]
        add('review_'+action['id'],'Review evidence: '+title,'The analyst review remains open; this does not mean the underlying probe was never executed.','Read the existing linked evidence, validate applicability, record conclusions and check Completed in the action note. Do not rerun completed data collection without a specific retest reason.',sources,5)
    if 'service_versions' in done and 'vuln_checks' not in done and not reviewed('run_vulnerability_checks'):
        add('collect_vuln_checks','Collect vulnerability-script evidence','No successful vulnerability-script measurement is stored.','Run non-intrusive Vulns checks, then review applicability.',done['service_versions'],5,'Vulns','Port Scope: Default; Intrusive NSE Checks: off; Speed Profile: Balanced; Dry-Run: off.')
    for finding in history['local_findings']:
        if finding['status'] not in ('Completed','Dismissed','Reviewed'):
            add('review_'+finding['id'],'Validate local indicator: '+finding['title'],'The imported indicator has an open analyst-validation state.','Review the finding card and its redacted transcript; verify the effective user, configuration and impact. Record validation without automatically executing imported commands.',[finding['source']],2 if finding['severity'] in ('High','Critical') else 4)
    return sorted(tasks,key=lambda task:(task['priority'],task['id']))


def evidence_link(source):
    return '['+source.replace('[','\\[').replace(']','\\]')+'](<' +quote(source,safe='/._-')+'>)'


def render_history(history):
    lines=['## Recorded test history — '+history['target'],'','These are evidence-derived collection results; completion does not confirm a vulnerability.','', '| Measurement | State | Evidence |','| --- | --- | --- |']
    for key,sources in sorted(history['completed'].items()):
        lines.append('| '+key+' | Completed | '+', '.join(evidence_link(s) for s in sources)+' |')
    for key,r in sorted(history['recon'].items()):
        if r['status']!='Completed':lines.append('| '+key+' | '+r['status']+' | '+evidence_link(r['source'])+' |')
    if not history['completed']:lines.append('| Network measurements | No successful, target-matched XML found | — |')
    for action in history['actions']:
        if action['review_complete']:
            lines+=['', '**Analyst-marked complete:** '+evidence_link(action['source'])+'. This records the analyst disposition separately from measured scan coverage.']
    snmp=history['snmp']
    if snmp['data_sources']:lines += ['','**SNMP data already collected:** '+', '.join(evidence_link(s) for s in snmp['data_sources'])+'. Review the disclosure; do not describe this as absent collection.']
    for item in snmp['community_reads']:lines+=['','**SNMP public read evidence:** version '+item['version']+'; '+evidence_link(item['source'])+'. '+item['status']+'.']
    if snmp['sensitive_sources']:lines+=['','**Potential sensitive SNMP process data:** '+', '.join(evidence_link(s) for s in snmp['sensitive_sources'])+'. Values are withheld from this planning state.']
    if history['warnings']:lines+=['','**Evidence limitations:**']+['- '+warning for warning in history['warnings'][:12]]
    return '\n'.join(lines)


def assess_target(session,target,model,question):
    from ai_advisor import _ask_ollama
    from peas_import import redact
    history=build_history(session,target)
    candidates=remaining_tasks(history)
    selected=candidates[:5]
    explanations={}
    accepted=False
    rejection_reasons=[]
    if selected:
        prompt='Explain only these preselected next tasks for target '+target+'. Do not add tests, repeat completed collection, switch targets or emit commands/settings. Distinguish acquisition from analyst review. Return JSON only: {"recommendations":[{"task_id":"exact id","rationale":"detailed evidence-based explanation","expected_outcome":"what validation establishes","decision":"what to do with each outcome"}]}. Default detail 10/10.\nTester request (scope cannot override target/history): '+redact(question)
        facts=redact(json.dumps(dict(history=history,permitted_tasks=selected)))
        for attempt in range(2):
            try:
                answer=_ask_ollama(model,prompt,facts,json_output=True)
            except Exception as exc:
                rejection_reasons.append('Local model unavailable: '+type(exc).__name__)
                break
            try:
                parsed=json.loads(answer)
                rows=parsed['recommendations']
                allowed={task['id'] for task in selected}
                if not isinstance(rows,list) or {r['task_id'] for r in rows}!=allowed or len(rows)!=len(allowed):
                    raise ValueError('Missing, duplicate or unsupported task IDs')
                for row in rows:
                    if not all(isinstance(row.get(k),str) and row[k].strip() for k in ('rationale','expected_outcome','decision')):
                        raise ValueError('Missing explanation fields')
                    text=' '.join(row[k] for k in ('rationale','expected_outcome','decision'))
                    if 'full_tcp' in history['completed'] and re.search(r'(?i)(?:run|perform|execute|missing|not (?:yet )?(?:done|performed|completed)).{0,60}(?:full tcp|full scan|65.?535)|(?:full tcp|full scan|65.?535).{0,60}(?:not (?:yet )?(?:done|performed|completed)|missing)',text):
                        raise ValueError('Contradicts completed full TCP evidence')
                    if any(cve not in facts for cve in re.findall(r'CVE-\d{4}-\d{4,}',text)):
                        raise ValueError('Invented CVE reference')
                    if history['snmp']['data_sources'] and re.search(r'(?i)(?:no|missing|absent).{0,30}(?:snmp|mib).{0,25}(?:results|output|evidence|data)',text):
                        raise ValueError('Contradicts collected SNMP data')
                    if any(ip != target for ip in re.findall(r'\b(?:\d{1,3}\.){3}\d{1,3}\b',text)):
                        raise ValueError('Explanation switches evidence target')
                    # Explanations cannot smuggle shell commands into the approved procedure.
                    if re.search(r'(?i)\b(?:sudo\s+(?:nmap|bash|snmpwalk)|nmap\s+-|snmpwalk\s+-|snmpget\s+-|curl\s+-|gobuster\s+(?:dir|dns|vhost)\s+-|bash\s+\./)',text):
                        raise ValueError('Commands belong to the controlled procedure, not model explanation')
                explanations={r['task_id']:r for r in rows}
                accepted=True
                break
            except (ValueError,KeyError,TypeError) as exc:
                rejection_reasons.append(str(exc))
                prompt+='\nPrior response failed validation. Include exactly the supplied task IDs and honor the recorded completed measurements.'
    lines=['# Evidence-aware next test plan','', '**Target:** '+target+' — other target directories are excluded.','',render_history(history),'','## Next steps — remaining collection or analyst validation','']
    if selected and not accepted:lines+=['The model response was unavailable or failed the completion checks. The evidence-derived plan below is retained; unsupported recommendations were discarded.','', '**Validation notes:** '+redact('; '.join(rejection_reasons)), '']
    if not selected:lines+=['No remaining tasks were identified by the current rules. Review scope and evidence freshness before defining additional testing.']
    for number,task in enumerate(selected,1):
        row=explanations.get(task['id'],{})
        lines += ['### '+str(number)+'. '+task['title'],'','**Task ID:** '+task['id']+' | **Priority:** '+str(task['priority'])+' | **Status:** Needs Action','', '**Purpose:** '+task['purpose'],'','**Mode:** '+task['mode'],'','**Settings:** '+task['settings'],'','**Procedure:** '+task['procedure'],'','**Evidence:** '+(', '.join(evidence_link(s) for s in task['sources']) or 'No successful stored measurement for this gap.')]
        if row:lines+=['','**Why this step:** '+redact(row['rationale']),'','**Expected outcome:** '+redact(row['expected_outcome']),'','**Decision after review:** '+redact(row['decision'])]
    if len(candidates)>5:lines+=['',str(len(candidates)-5)+' additional open tasks remain; the five highest-priority tasks are shown.']
    return '\n'.join(lines)+'\n'
