"""Portable Windows entry point; application failures are shown and logged."""
import os
import pathlib
import sys
import traceback

ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)
sys.dont_write_bytecode = True

if __name__ == '__main__':
    try:
        from nmap_obsidian_gui import main
        main()
    except Exception:
        details = traceback.format_exc()
        (ROOT / 'startup-error.log').write_text(details, encoding='utf-8')
        try:
            import tkinter as tk
            from tkinter import messagebox
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror('Dashboard startup failed', 'See startup-error.log in the extracted tool folder.\n\n' + details.splitlines()[-1])
            root.destroy()
        finally:
            raise SystemExit(1)
