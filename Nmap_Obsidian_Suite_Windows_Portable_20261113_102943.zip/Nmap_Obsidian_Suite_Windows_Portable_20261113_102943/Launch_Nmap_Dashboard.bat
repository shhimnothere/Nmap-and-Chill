@echo off
start "" "%~dp0Start_Nmap_Dashboard.exe"
