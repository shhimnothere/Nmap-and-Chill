#!/usr/bin/env python3
"""
NmapAutomator Kali Obsidian Dashboard v6.3 — Cross-Platform Desktop GUI Launcher (Linux & Windows)

Features:
- Startup Test Session Manager: Choose to CONTINUE an existing serialized test session or CREATE a new one.
- Strict Evidence Isolation: Every test session gets its own serialized folder (CTP-YYYYMMDD-HHMMSS_<Name>)
  and isolated Obsidian Session Hub (00_SESSION_HUB.md) so scans from one test never mix with another.
- Automated Report-Ready Enumeration Section (02_ENUMERATION_REPORT_DRAFT.md) with SHA-256 chain of custody.
- Automatic Obsidian Vault Registration & Live Vault Linking (prevents 'Vault not found').
"""

import hashlib
import json
import os
import pathlib
import queue
import shutil
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
import urllib.parse
import webbrowser

import session_manager as sm


APP_DIR = pathlib.Path(__file__).resolve().parent
SCRIPT_PATH = APP_DIR / "NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh"
TEST_SUITE_PATH = APP_DIR / "tests" / "security_qa_regression.py"

if os.name != "nt" and str(APP_DIR).startswith("/usr/"):
    DEFAULT_SCANS_DIR = pathlib.Path.home() / "nmap-obsidian-scans"
else:
    DEFAULT_SCANS_DIR = APP_DIR / "scans"

SESSIONS_ROOT = DEFAULT_SCANS_DIR / "sessions"


def to_exec_path(path: pathlib.Path) -> str:
    resolved = str(path.resolve())
    if os.name == "nt" and len(resolved) >= 2 and resolved[1] == ":":
        drive = resolved[0].lower()
        tail = resolved[2:].replace("\\", "/")
        return f"/mnt/{drive}{tail}"
    return resolved


def get_obsidian_config_path() -> pathlib.Path:
    if os.name == "nt":
        appdata = os.environ.get("APPDATA") or str(pathlib.Path.home() / "AppData" / "Roaming")
        return pathlib.Path(appdata) / "obsidian" / "obsidian.json"
    return pathlib.Path.home() / ".config" / "obsidian" / "obsidian.json"


def ensure_directory_link(link_path: pathlib.Path, target_dir: pathlib.Path) -> bool:
    """Create a directory junction (Windows) or symlink (Linux) so an already-open Obsidian vault sees scans."""
    try:
        if link_path.exists() or link_path.is_symlink():
            return True
        link_path.parent.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            subprocess.run(
                ["cmd", "/c", "mklink", "/J", str(link_path), str(target_dir.resolve())],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=True,
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
        else:
            link_path.symlink_to(target_dir.resolve(), target_is_directory=True)
        return True
    except Exception:
        return False


def open_note_in_obsidian(md_file: pathlib.Path, vault_root: pathlib.Path = DEFAULT_SCANS_DIR) -> str:
    """
    Ensure Obsidian knows the vault and open md_file without triggering 'Vault not found'.
    """
    vault_root = vault_root.resolve()
    md_file = md_file.resolve()

    from obsidian_setup import configure_vault
    configure_vault(vault_root)

    obs_meta = vault_root / ".obsidian"
    obs_meta.mkdir(parents=True, exist_ok=True)
    app_json = obs_meta / "app.json"
    if not app_json.exists():
        app_json.write_text('{"alwaysUpdateLinks": true, "useMarkdownLinks": true}\n', encoding="utf-8")

    cfg_path = get_obsidian_config_path()
    vault_name = vault_root.name
    try:
        rel_inside_out = md_file.relative_to(vault_root).as_posix()
    except ValueError:
        vault_root = md_file.parent
        vault_name = vault_root.name
        rel_inside_out = md_file.name

    if rel_inside_out.endswith(".md"):
        rel_inside_out = rel_inside_out[:-3]

    open_vault_path = None
    open_vault_name = None

    if cfg_path.is_file():
        try:
            cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
        except Exception:
            cfg = {"vaults": {}}
    else:
        cfg = {"vaults": {}}

    vaults = cfg.setdefault("vaults", {})
    out_str = str(vault_root)
    registered_out = False

    for vid, vinfo in vaults.items():
        vpath_str = vinfo.get("path", "")
        if not vpath_str:
            continue
        vpath = pathlib.Path(vpath_str)
        try:
            if vpath.resolve() == vault_root:
                registered_out = True
                vault_name = vpath.name
            elif vinfo.get("open") and vpath.is_dir():
                open_vault_path = vpath.resolve()
                open_vault_name = vpath.name
        except OSError:
            continue

    if not registered_out:
        vid = hashlib.sha256(out_str.encode("utf-8")).hexdigest()[:16]
        vaults[vid] = {
            "path": out_str,
            "ts": int(time.time() * 1000),
            "open": True,
        }
        try:
            cfg_path.parent.mkdir(parents=True, exist_ok=True)
            cfg_path.write_text(json.dumps(cfg), encoding="utf-8")
        except OSError:
            pass

    if open_vault_path is not None:
        configure_vault(open_vault_path)
        try:
            direct_rel = md_file.relative_to(open_vault_path).as_posix()
            if direct_rel.endswith(".md"):
                direct_rel = direct_rel[:-3]
            uri = (
                "obsidian://open?vault="
                + urllib.parse.quote(open_vault_name, safe="")
                + "&file="
                + urllib.parse.quote(direct_rel, safe="/")
            )
            open_obsidian_with_viewers(uri, str(open_vault_path))
            return uri
        except ValueError:
            junction_path = open_vault_path / "Nmap_Scans"
            if ensure_directory_link(junction_path, vault_root):
                linked_rel = f"Nmap_Scans/{rel_inside_out}"
                uri = (
                    "obsidian://open?vault="
                    + urllib.parse.quote(open_vault_name, safe="")
                    + "&file="
                    + urllib.parse.quote(linked_rel, safe="/")
                )
                open_obsidian_with_viewers(uri, str(open_vault_path))
                return uri

    uri = (
        "obsidian://open?vault="
        + urllib.parse.quote(vault_name, safe="")
        + "&file="
        + urllib.parse.quote(rel_inside_out, safe="/")
    )
    open_obsidian_with_viewers(uri, str(vault_root))
    return uri


def open_obsidian_with_viewers(uri, vault_name):
    webbrowser.open(uri)
    def enable():
        from obsidian_setup import enable_viewers
        time.sleep(2)
        try:
            enable_viewers(vault_name)
        except Exception as exc:
            # Surface setup errors instead of silently claiming plugins are enabled.
            print(f"Obsidian viewer setup: {exc}", file=sys.stderr)
    threading.Thread(target=enable, daemon=True).start()


def collect_available_dashboards(session_dir: pathlib.Path, preferred_target: str = "") -> list[tuple[str, pathlib.Path]]:
    """Return a prioritized list of (label, path) for all session, subnet, and host notes in session_dir."""
    items: list[tuple[str, pathlib.Path]] = []
    if not session_dir.is_dir():
        return items

    # 1. Session Hub & Enumeration Report Draft
    hub = session_dir / "00_SESSION_HUB.md"
    if hub.is_file():
        items.append(("🗂 Session Hub (00_SESSION_HUB.md)", hub))
    rep = session_dir / "02_ENUMERATION_REPORT_DRAFT.md"
    if rep.is_file():
        items.append(("📄 Report-Ready Enumeration Section (02_ENUMERATION_REPORT_DRAFT.md)", rep))

    # 2. Legacy Master Overview if present
    master = session_dir / "00_NETWORK_OVERVIEW.md"
    if master.is_file():
        items.append(("🌐 Master Network Overview (00_NETWORK_OVERVIEW.md)", master))

    # 3. Subnet Summaries (newest first)
    subnet_notes = sorted(
        session_dir.glob("subnets/*/*/subnet_summary.md"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    for sn in subnet_notes:
        subnet_label = sn.parent.parent.name.replace("_", "/")
        items.append((f"🖧 Subnet Summary: {subnet_label} ({sn.parent.name})", sn))

    # 4. Host Target Dashboards
    host_dashboards = sorted(
        session_dir.glob("*/00_TARGET_DASHBOARD.md"),
        key=lambda p: (p.parent.name != preferred_target, -p.stat().st_mtime),
    )
    for hd in host_dashboards:
        ip_name = hd.parent.name
        items.append((f"🖥 Host Dashboard: {ip_name} (00_TARGET_DASHBOARD.md)", hd))
        findings = hd.parent / "01_FINDINGS.md"
        if findings.is_file():
            items.append((f"   ↳ Validated Findings: {ip_name} (01_FINDINGS.md)", findings))

    # 5. Master All-Sessions Index
    all_idx = session_dir.parent / "00_ALL_TEST_SESSIONS_INDEX.md"
    if all_idx.is_file():
        items.append(("📚 All Serialized Test Sessions Index (00_ALL_TEST_SESSIONS_INDEX.md)", all_idx))

    if preferred_target and (session_dir / preferred_target / "00_TARGET_DASHBOARD.md").is_file():
        exact = session_dir / preferred_target / "00_TARGET_DASHBOARD.md"
        items.sort(key=lambda pair: 0 if pair[1] == exact else 1)

    return items


class NmapObsidianGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("NmapAutomator v6.3 — Kali & Obsidian Cyber Test Plan Suite")
        self.root.geometry("1220x860")
        self.root.minsize(1020, 720)
        self.root.configure(bg="#0f172a")

        self.proc = None
        self.log_queue: queue.Queue[str] = queue.Queue()
        self.is_running = False

        self.ui_font = "Segoe UI" if os.name == "nt" else "DejaVu Sans"
        self.mono_font = "Consolas" if os.name == "nt" else "Monospace"

        # Migrate any un-serialized scans into CTP-YYYYMMDD-001 automatically
        sm.migrate_legacy_root_scans(DEFAULT_SCANS_DIR, SESSIONS_ROOT)
        self.active_session = sm.get_active_session(SESSIONS_ROOT)
        if not self.active_session:
            self.active_session = sm.create_session(
                name="Initial Network Test",
                operator="Lead Analyst",
                scope_notes="Baseline Cyber Test Plan Enumeration",
                sessions_root=SESSIONS_ROOT,
            )

        self._configure_styles()
        self._build_ui()
        self._poll_log_queue()
        # Show the Session Manager modal on startup so the user can choose to Continue or Create New Test
        self.root.after(150, self.open_session_manager_dialog)

    def _configure_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        bg_main = "#0f172a"
        bg_card = "#1e293b"
        fg_text = "#f8fafc"
        accent = "#38bdf8"

        style.configure("TFrame", background=bg_main)
        style.configure("Card.TFrame", background=bg_card)
        style.configure("Banner.TFrame", background="#172554")
        style.configure("TLabel", background=bg_card, foreground=fg_text, font=(self.ui_font, 10))
        style.configure("Header.TLabel", background=bg_main, foreground=accent, font=(self.ui_font, 15, "bold"))
        style.configure("SubHeader.TLabel", background=bg_main, foreground="#94a3b8", font=(self.ui_font, 9))
        style.configure("BannerTitle.TLabel", background="#172554", foreground="#38bdf8", font=(self.ui_font, 11, "bold"))
        style.configure("BannerSub.TLabel", background="#172554", foreground="#cbd5e1", font=(self.mono_font, 9))
        style.configure("Section.TLabel", background=bg_card, foreground=accent, font=(self.ui_font, 10, "bold"))
        style.configure("TCheckbutton", background=bg_card, foreground=fg_text, font=(self.ui_font, 9))
        style.map("TCheckbutton", background=[("active", bg_card)])
        style.configure("TCombobox", fieldbackground="#0f172a", background="#334155", foreground="#0f172a")
        style.configure(
            "Treeview",
            background="#0f172a",
            foreground="#f8fafc",
            fieldbackground="#0f172a",
            rowheight=26,
            font=(self.mono_font, 9),
        )
        style.configure("Treeview.Heading", background="#334155", foreground="#38bdf8", font=(self.ui_font, 9, "bold"))
        style.map("Treeview", background=[("selected", "#0284c7")])

    def _build_ui(self):
        # Top Header
        header_frame = ttk.Frame(self.root)
        header_frame.pack(fill="x", padx=16, pady=(10, 4))
        ttk.Label(
            header_frame,
            text="NmapAutomator v6.3 — Kali & Obsidian Cyber Test Plan Suite",
            style="Header.TLabel",
        ).pack(anchor="w")
        ttk.Label(
            header_frame,
            text="Serialized Evidence Isolation · Report-Ready Enumeration · Obsidian Session Hubs · Security QA Suite",
            style="SubHeader.TLabel",
        ).pack(anchor="w")

        # Active Serialized Session Banner
        banner = ttk.Frame(self.root, style="Banner.TFrame", padding=10)
        banner.pack(fill="x", padx=16, pady=(2, 6))

        left_banner = ttk.Frame(banner, style="Banner.TFrame")
        left_banner.pack(side="left", fill="x", expand=True)
        self.session_badge_var = tk.StringVar()
        self.session_path_var = tk.StringVar()
        ttk.Label(left_banner, textvariable=self.session_badge_var, style="BannerTitle.TLabel").pack(anchor="w")
        ttk.Label(left_banner, textvariable=self.session_path_var, style="BannerSub.TLabel").pack(anchor="w")

        tk.Button(
            banner,
            text="🗂 Switch / Create New Test Session",
            command=self.open_session_manager_dialog,
            bg="#0284c7",
            fg="#ffffff",
            font=(self.ui_font, 9, "bold"),
            relief="flat",
            padx=12,
            pady=5,
        ).pack(side="right", padx=(8, 0))

        tk.Button(
            banner,
            text="📄 Build & View Enumeration Report",
            command=self.open_enumeration_report_window,
            bg="#0d9488",
            fg="#ffffff",
            font=(self.ui_font, 9, "bold"),
            relief="flat",
            padx=12,
            pady=5,
        ).pack(side="right")

        advisor_bar = ttk.Frame(self.root)
        advisor_bar.pack(fill="x", padx=16, pady=4)
        ttk.Button(advisor_bar, text="AI Advisor — Recommend Next Tests",
                   command=self.open_ai_advisor).pack(side="left")
        ttk.Label(advisor_bar, text="Local Ollama · Evidence-based test planning", style="SubHeader.TLabel").pack(side="left", padx=12)

        self.ai_findings_var = tk.BooleanVar(value=True)
        self.ai_model_var = tk.StringVar(value="qwen3.5:9b")
        ttk.Checkbutton(advisor_bar, text="AI findings after scan", variable=self.ai_findings_var).pack(side="left", padx=8)
        ttk.Entry(advisor_bar, textvariable=self.ai_model_var, width=16).pack(side="left")
        ttk.Button(advisor_bar, text="Update AI Findings", command=self.update_ai_findings).pack(side="left", padx=8)

        imports_bar = ttk.Frame(self.root)
        imports_bar.pack(fill="x", padx=16, pady=3)
        ttk.Button(imports_bar, text="Import LinPEAS / WinPEAS…", command=self.import_peas_files).pack(side="left")
        ttk.Button(imports_bar, text="Refresh Dropped PEAS Files", command=self.refresh_peas_imports).pack(side="left", padx=8)
        ttk.Button(imports_bar, text="Open Target Imports", command=self.open_peas_imports).pack(side="left")
        self.peas_auto_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(imports_bar, text="Watch imports", variable=self.peas_auto_var).pack(side="left", padx=8)
        self._peas_signature = None
        self.root.after(10000, self._watch_peas_imports)

        # Main Controls Card
        card = ttk.Frame(self.root, style="Card.TFrame", padding=12)
        card.pack(fill="x", padx=16, pady=4)

        # Row 0: Target, Mode, Scope, Speed Profile
        row0 = ttk.Frame(card, style="Card.TFrame")
        row0.pack(fill="x", pady=4)

        ttk.Label(row0, text="Target (IPv4 or /24 CIDR):").pack(side="left", padx=(0, 6))
        scanned_targets = sorted(p.parent.name for p in pathlib.Path(self.active_session["path"]).glob("*/Runs") if p.is_dir())
        restored_target = scanned_targets[0] if len(scanned_targets) == 1 else "127.0.0.1"
        self.target_var = tk.StringVar(value=restored_target)
        self.target_entry = tk.Entry(
            row0, textvariable=self.target_var, width=18,
            bg="#0f172a", fg="#f8fafc", insertbackground="#f8fafc", font=(self.mono_font, 10)
        )
        self.target_entry.pack(side="left", padx=(0, 14))

        ttk.Label(row0, text="Scan Mode:").pack(side="left", padx=(0, 6))
        self.mode_var = tk.StringVar(value="Basic")
        self.mode_combo = ttk.Combobox(
            row0, textvariable=self.mode_var, width=12, state="readonly",
            values=["Quick", "Basic", "UDP", "Full", "Vulns", "Recon", "All", "Dashboard"]
        )
        self.mode_combo.pack(side="left", padx=(0, 14))

        ttk.Label(row0, text="Port Scope:").pack(side="left", padx=(0, 6))
        self.scope_var = tk.StringVar(value="Default")
        self.scope_combo = ttk.Combobox(
            row0, textvariable=self.scope_var, width=16, state="readonly",
            values=["Default", "All 65535 (-p-)", "Top Ports (--top-ports)", "Custom Ports (-p)"]
        )
        self.scope_combo.pack(side="left", padx=(0, 6))

        self.port_val_var = tk.StringVar(value="100")
        self.port_val_entry = tk.Entry(
            row0, textvariable=self.port_val_var, width=10,
            bg="#0f172a", fg="#f8fafc", insertbackground="#f8fafc", font=(self.mono_font, 10)
        )
        self.port_val_entry.pack(side="left", padx=(0, 14))

        ttk.Label(row0, text="Speed Profile:").pack(side="left", padx=(0, 6))
        self.profile_var = tk.StringVar(value="Fast (--fast)")
        self.profile_combo = ttk.Combobox(
            row0, textvariable=self.profile_var, width=15, state="readonly",
            values=["Default", "Fast (--fast)", "Balanced", "Stealth (-T2)", "-T3", "-T4", "-T5"]
        )
        self.profile_combo.pack(side="left")

        # Row 1: Session Output Dir + Optional Targets File + SNMP
        row1 = ttk.Frame(card, style="Card.TFrame")
        row1.pack(fill="x", pady=6)

        ttk.Label(row1, text="Session Evidence Folder:").pack(side="left", padx=(0, 6))
        self.output_var = tk.StringVar(value=str(self.active_session["path"]))
        out_entry = tk.Entry(
            row1, textvariable=self.output_var, width=42, state="readonly",
            readonlybackground="#0f172a", fg="#38bdf8", font=(self.mono_font, 9)
        )
        out_entry.pack(side="left", padx=(0, 12))

        ttk.Label(row1, text="Targets File (Optional):").pack(side="left", padx=(0, 6))
        self.targets_file_var = tk.StringVar(value="")
        tf_entry = tk.Entry(
            row1, textvariable=self.targets_file_var, width=22,
            bg="#0f172a", fg="#f8fafc", insertbackground="#f8fafc", font=(self.mono_font, 9)
        )
        tf_entry.pack(side="left", padx=(0, 4))
        tk.Button(
            row1, text="File...", command=self._browse_targets_file,
            bg="#334155", fg="#f8fafc", relief="flat", padx=6
        ).pack(side="left", padx=(0, 12))

        ttk.Label(row1, text="SNMP:").pack(side="left", padx=(0, 4))
        self.snmp_var = tk.StringVar(value="")
        tk.Entry(
            row1, textvariable=self.snmp_var, width=10,
            bg="#0f172a", fg="#f8fafc", insertbackground="#f8fafc", font=(self.mono_font, 9)
        ).pack(side="left")

        # Row 2: Checkboxes
        row2 = ttk.Frame(card, style="Card.TFrame")
        row2.pack(fill="x", pady=4)

        self.run_recon_var = tk.BooleanVar(value=True)
        self.parallel_recon_var = tk.BooleanVar(value=True)
        self.web_deep_var = tk.BooleanVar(value=False)
        self.fresh_var = tk.BooleanVar(value=False)
        self.no_ping_var = tk.BooleanVar(value=False)
        self.intrusive_var = tk.BooleanVar(value=False)
        self.dry_run_var = tk.BooleanVar(value=False)
        self.root_mode_var = tk.BooleanVar(value=(os.name == "nt" or (hasattr(os, "geteuid") and os.geteuid() == 0)))

        ttk.Checkbutton(row2, text="Execute Recon (--run-recon)", variable=self.run_recon_var).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(row2, text="Parallel Fast Probes (--parallel-recon)", variable=self.parallel_recon_var).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(row2, text="Deep Web: Nikto/Gobuster (--web-deep)", variable=self.web_deep_var).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(row2, text="Force Fresh (--fresh)", variable=self.fresh_var).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(row2, text="Skip Ping (--no-ping)", variable=self.no_ping_var).pack(side="left", padx=(0, 12))

        row3 = ttk.Frame(card, style="Card.TFrame")
        row3.pack(fill="x", pady=2)
        root_label = "WSL Root Mode (UDP/Raw Sockets)" if os.name == "nt" else "Elevate with sudo/pkexec (UDP/Raw Sockets)"
        ttk.Checkbutton(row3, text=root_label, variable=self.root_mode_var).pack(side="left", padx=(0, 14))
        ttk.Checkbutton(row3, text="Dry-Run Pre-Flight Only (--dry-run)", variable=self.dry_run_var).pack(side="left", padx=(0, 14))
        ttk.Checkbutton(row3, text="Intrusive NSE Checks (--intrusive)", variable=self.intrusive_var).pack(side="left", padx=(0, 14))

        # Action Toolbar
        btn_bar = ttk.Frame(self.root)
        btn_bar.pack(fill="x", padx=16, pady=6)

        self.run_btn = tk.Button(
            btn_bar, text="▶ Run Scan in Active Session", command=self.start_scan,
            bg="#0284c7", fg="#ffffff", font=(self.ui_font, 10, "bold"), relief="flat", padx=12, pady=6
        )
        self.run_btn.pack(side="left", padx=(0, 6))

        self.stop_btn = tk.Button(
            btn_bar, text="⏹ Stop", command=self.stop_process, state="disabled",
            bg="#dc2626", fg="#ffffff", font=(self.ui_font, 10, "bold"), relief="flat", padx=10, pady=6
        )
        self.stop_btn.pack(side="left", padx=(0, 10))

        tk.Button(
            btn_bar, text="🚀 Open Session in Obsidian", command=self.launch_obsidian_direct,
            bg="#9333ea", fg="#ffffff", font=(self.ui_font, 9, "bold"), relief="flat", padx=12, pady=6
        ).pack(side="left", padx=(0, 6))

        tk.Button(
            btn_bar, text="📓 Preview Dashboards", command=self.open_dashboard_preview,
            bg="#334155", fg="#f8fafc", font=(self.ui_font, 9, "bold"), relief="flat", padx=10, pady=6
        ).pack(side="left", padx=(0, 6))

        tk.Button(
            btn_bar, text="🌐 Open HTML Report", command=self.open_latest_html,
            bg="#334155", fg="#f8fafc", font=(self.ui_font, 9, "bold"), relief="flat", padx=10, pady=6
        ).pack(side="left", padx=(0, 6))

        tk.Button(
            btn_bar, text="🛡 Security QA Tests", command=self.run_qa_tests,
            bg="#4f46e5", fg="#ffffff", font=(self.ui_font, 9, "bold"), relief="flat", padx=10, pady=6
        ).pack(side="left", padx=(0, 6))

        tk.Button(
            btn_bar, text="✔ Check Deps", command=self.run_dependency_check,
            bg="#059669", fg="#ffffff", font=(self.ui_font, 9, "bold"), relief="flat", padx=10, pady=6
        ).pack(side="left", padx=(0, 6))

        tk.Button(
            btn_bar, text="📂 Session Folder", command=self.open_output_folder,
            bg="#334155", fg="#f8fafc", font=(self.ui_font, 9), relief="flat", padx=10, pady=6
        ).pack(side="left")

        # Console Output Area
        console_frame = ttk.Frame(self.root, style="Card.TFrame", padding=10)
        console_frame.pack(fill="both", expand=True, padx=16, pady=(2, 12))

        top_console = ttk.Frame(console_frame, style="Card.TFrame")
        top_console.pack(fill="x", pady=(0, 6))
        self.status_label = ttk.Label(top_console, text="Ready.", style="Section.TLabel")
        self.status_label.pack(side="left")
        tk.Button(
            top_console, text="Clear Console", command=self._clear_console,
            bg="#334155", fg="#f8fafc", font=(self.ui_font, 8), relief="flat", padx=8
        ).pack(side="right")

        self.console = scrolledtext.ScrolledText(
            console_frame, bg="#090d16", fg="#e2e8f0", insertbackground="#38bdf8",
            font=(self.mono_font, 10), relief="flat", wrap="word"
        )
        self.console.pack(fill="both", expand=True)

        self._refresh_session_banner()

    def _refresh_session_banner(self):
        s = self.active_session
        self.output_var.set(str(s["path"]))
        self.session_badge_var.set(
            f"ACTIVE TEST SESSION: {s['session_id']} — {s['name']}   (Analyst: {s['operator']} · Hosts in Session: {s['target_count']})"
        )
        self.session_path_var.set(f"Isolated Evidence Path: {s['path']}")

    def open_session_manager_dialog(self):
        """Modal dialog allowing the user to Continue an existing serialized test session or Create a new one."""
        dlg = tk.Toplevel(self.root)
        dlg.title("Cyber Test Plan — Select or Create Serialized Test Session")
        dlg.geometry("860x580")
        dlg.configure(bg="#0f172a")
        dlg.transient(self.root)
        dlg.grab_set()

        hdr = ttk.Frame(dlg)
        hdr.pack(fill="x", padx=16, pady=(14, 6))
        ttk.Label(
            hdr,
            text="🗂 Cyber Test Plan — Session & Evidence Isolation Manager",
            style="Header.TLabel",
        ).pack(anchor="w")
        ttk.Label(
            hdr,
            text="Choose an existing serialized test session to continue working on, or create a new isolated test session so evidence never mixes.",
            style="SubHeader.TLabel",
        ).pack(anchor="w")

        # Section 1: Continue Existing Session
        existing_card = ttk.Frame(dlg, style="Card.TFrame", padding=12)
        existing_card.pack(fill="both", expand=True, padx=16, pady=6)
        ttk.Label(
            existing_card,
            text="Option 1: Continue Working on an Existing Serialized Test Session",
            style="Section.TLabel",
        ).pack(anchor="w", pady=(0, 6))

        cols = ("serial", "name", "operator", "hosts", "updated")
        tree = ttk.Treeview(existing_card, columns=cols, show="headings", height=6)
        tree.heading("serial", text="Serial ID")
        tree.heading("name", text="Test / Engagement Name")
        tree.heading("operator", text="Analyst")
        tree.heading("hosts", text="Hosts")
        tree.heading("updated", text="Last Updated")
        tree.column("serial", width=155, anchor="w")
        tree.column("name", width=250, anchor="w")
        tree.column("operator", width=120, anchor="w")
        tree.column("hosts", width=70, anchor="center")
        tree.column("updated", width=165, anchor="w")
        tree.pack(fill="both", expand=True, pady=4)

        sessions = sm.list_sessions(SESSIONS_ROOT)
        for idx, s in enumerate(sessions):
            iid = str(idx)
            tree.insert(
                "",
                "end",
                iid=iid,
                values=(s["session_id"], s["name"], s["operator"], s["target_count"], s["updated_at"][:16].replace("T", " ")),
            )
            if self.active_session and s["path"].resolve() == self.active_session["path"].resolve():
                tree.selection_set(iid)

        def on_continue_selected():
            sel = tree.selection()
            if not sel:
                messagebox.showwarning("Select Session", "Please select a test session from the list.", parent=dlg)
                return
            chosen = sessions[int(sel[0])]
            sm.set_active_session(chosen["path"], SESSIONS_ROOT)
            self.active_session = chosen
            self._refresh_session_banner()
            self._log(
                f"\n[SESSION] Continued existing test session: {chosen['session_id']} — {chosen['name']}\n"
                f"          Isolated folder: {chosen['path']}\n"
            )
            dlg.destroy()

        btn_row1 = ttk.Frame(existing_card, style="Card.TFrame")
        btn_row1.pack(fill="x", pady=(6, 0))
        tk.Button(
            btn_row1,
            text="▶ Continue Selected Test Session",
            command=on_continue_selected,
            bg="#0284c7",
            fg="#ffffff",
            font=(self.ui_font, 10, "bold"),
            relief="flat",
            padx=14,
            pady=5,
        ).pack(side="left")

        # Section 2: Create New Serialized Session
        new_card = ttk.Frame(dlg, style="Card.TFrame", padding=12)
        new_card.pack(fill="x", padx=16, pady=(6, 14))

        next_id = sm.next_serial_id(SESSIONS_ROOT)
        ttk.Label(
            new_card,
            text=f"Option 2: Create a New Isolated Test Session (Next Serial ID: {next_id})",
            style="Section.TLabel",
        ).pack(anchor="w", pady=(0, 8))

        form = ttk.Frame(new_card, style="Card.TFrame")
        form.pack(fill="x", pady=2)

        ttk.Label(form, text="Test Name:").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=4)
        new_name_var = tk.StringVar(value="Segment_Enumeration")
        tk.Entry(
            form, textvariable=new_name_var, width=28,
            bg="#0f172a", fg="#f8fafc", insertbackground="#f8fafc", font=(self.mono_font, 10)
        ).grid(row=0, column=1, sticky="w", padx=(0, 16), pady=4)

        ttk.Label(form, text="Analyst:").grid(row=0, column=2, sticky="w", padx=(0, 8), pady=4)
        new_op_var = tk.StringVar(value="Lead Analyst")
        tk.Entry(
            form, textvariable=new_op_var, width=18,
            bg="#0f172a", fg="#f8fafc", insertbackground="#f8fafc", font=(self.mono_font, 10)
        ).grid(row=0, column=3, sticky="w", pady=4)

        ttk.Label(form, text="Scope / Objective:").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=4)
        new_scope_var = tk.StringVar(value="Authorized cyber test plan enumeration & service discovery")
        tk.Entry(
            form, textvariable=new_scope_var, width=62,
            bg="#0f172a", fg="#f8fafc", insertbackground="#f8fafc", font=(self.mono_font, 9)
        ).grid(row=1, column=1, columnspan=3, sticky="we", pady=4)

        def on_create_new():
            tname = new_name_var.get().strip()
            if not tname:
                messagebox.showerror("Missing Test Name", "Please enter a name for the new test session.", parent=dlg)
                return
            created = sm.create_session(
                name=tname,
                operator=new_op_var.get().strip() or "Lead Analyst",
                scope_notes=new_scope_var.get().strip(),
                sessions_root=SESSIONS_ROOT,
            )
            self.active_session = created
            self._refresh_session_banner()
            self._log(
                f"\n[NEW SESSION CREATED] {created['session_id']} — {created['name']}\n"
                f"                      Isolated folder: {created['path']}\n"
                f"                      Session Hub:     {created['path'] / '00_SESSION_HUB.md'}\n"
            )
            dlg.destroy()

        btn_row2 = ttk.Frame(new_card, style="Card.TFrame")
        btn_row2.pack(fill="x", pady=(8, 0))
        tk.Button(
            btn_row2,
            text=f"➕ Create & Start New Session ({next_id})",
            command=on_create_new,
            bg="#059669",
            fg="#ffffff",
            font=(self.ui_font, 10, "bold"),
            relief="flat",
            padx=14,
            pady=5,
        ).pack(side="left")

    def _peas_target(self):
        import ipaddress
        target = self.target_var.get().strip()
        ipaddress.IPv4Address(target)
        root = pathlib.Path(self.active_session["path"]).resolve()
        host = root / target
        if host.is_symlink() or not host.resolve().is_relative_to(root):
            raise ValueError("Unsafe target folder")
        folder = host / "imports"
        folder.mkdir(parents=True, exist_ok=True)
        return host

    def open_peas_imports(self):
        try:
            folder = self._peas_target() / "imports"
            if os.name == "nt":
                os.startfile(str(folder))
            else:
                subprocess.Popen(["xdg-open", str(folder)])
        except Exception as exc:
            messagebox.showerror("PEAS imports", str(exc))

    def import_peas_files(self):
        files = filedialog.askopenfilenames(title="Import PEAS output (evidence only)", filetypes=[("PEAS evidence", "*.txt *.log *.out *.ansi")])
        if files:
            self.refresh_peas_imports(files)

    def refresh_peas_imports(self, files=()):
        if self.is_running:
            self._log("[PEAS] Wait for the current task to finish before importing.\n")
            return
        try:
            target = self._peas_target()
        except Exception as exc:
            messagebox.showerror("PEAS imports", "Select one IPv4 target: " + str(exc))
            return
        session = target.parent
        model = self.ai_model_var.get().strip() or "qwen3.5:9b"
        self.is_running = True
        self.run_btn.configure(state="disabled")
        self.status_label.configure(text="Importing local enumeration evidence…")
        def worker():
            try:
                from peas_import import import_target
                import_target(target, files, model=model, log=lambda text:self._log(text + "\n"))
                sm.build_session_enumeration_report(session)
            except Exception as exc:
                self._log(f"[PEAS ERROR] {exc}\n")
            finally:
                self.root.after(0, finish)
        def finish():
            self.is_running = False
            self.run_btn.configure(state="normal")
            self.status_label.configure(text="PEAS import finished — see console for counts and warnings")
        threading.Thread(target=worker, daemon=True).start()

    def _watch_peas_imports(self):
        try:
            if self.peas_auto_var.get() and not self.is_running:
                target = self._peas_target()
                signature = tuple((str(p), p.stat().st_size, p.stat().st_mtime_ns) for p in sorted((target / "imports").iterdir()) if p.suffix.lower() in {".txt", ".log", ".out", ".ansi"} and p.is_file() and not p.is_symlink())
                # Wait for the same snapshot on two polling cycles before reading a drop.
                if signature and signature == getattr(self, "_peas_pending", None) and signature != self._peas_signature:
                    self._peas_signature = signature
                    self.refresh_peas_imports()
                self._peas_pending = signature
        except (OSError, ValueError):
            pass
        self.root.after(10000, self._watch_peas_imports)

    def update_ai_findings(self):
        if self.is_running:
            messagebox.showinfo("Busy", "Wait for the current scan or analysis to finish.")
            return
        session = self.active_session["path"]
        model = self.ai_model_var.get().strip() or "qwen3.5:9b"
        self.is_running = True
        self.run_btn.configure(state="disabled")
        self.status_label.configure(text="Analyzing findings with local AI…")
        def worker():
            try:
                from ai_advisor import update_session_findings
                paths = update_session_findings(session, model, self._log)
                self._log(f"[AI] Updated {len(paths)} findings page(s).\n")
                sm.build_session_enumeration_report(session)
            except Exception as exc:
                self._log(f"[AI ERROR] {exc}\n")
            finally:
                self.root.after(0, finish)
        def finish():
            self.is_running = False
            self.run_btn.configure(state="normal")
            self.status_label.configure(text="AI analysis finished — see console for results")
        threading.Thread(target=worker, daemon=True).start()

    def open_ai_advisor(self):
        from ai_advisor import open_advisor
        open_advisor(self)

    def open_enumeration_report_window(self):
        """Build and preview the Report-Ready Enumeration Section (02_ENUMERATION_REPORT_DRAFT.md) for the active session."""
        sdir = self.active_session["path"]
        report_path = sm.build_session_enumeration_report(sdir)
        sm.update_all_sessions_index(SESSIONS_ROOT)
        self.active_session = sm.get_active_session(SESSIONS_ROOT) or self.active_session
        self._refresh_session_banner()

        win = tk.Toplevel(self.root)
        win.title(f"Report-Ready Enumeration Section — {self.active_session['session_id']}")
        win.geometry("980x720")
        win.configure(bg="#0f172a")

        bar = ttk.Frame(win)
        bar.pack(fill="x", padx=12, pady=10)
        ttk.Label(bar, text=str(report_path), style="SubHeader.TLabel").pack(side="left")

        content = report_path.read_text(encoding="utf-8", errors="replace")

        def copy_to_clipboard():
            self.root.clipboard_clear()
            self.root.clipboard_append(content)
            messagebox.showinfo("Copied", "Enumeration report Markdown copied to clipboard!", parent=win)

        def open_in_obsidian():
            uri = open_note_in_obsidian(report_path, DEFAULT_SCANS_DIR)
            self._log(f"\n[OBSIDIAN] Opened Enumeration Report via {uri}\n")

        tk.Button(
            bar, text="🚀 Open in Obsidian App", command=open_in_obsidian,
            bg="#9333ea", fg="#ffffff", font=(self.ui_font, 9, "bold"), relief="flat", padx=10, pady=4
        ).pack(side="right", padx=4)

        tk.Button(
            bar, text="📋 Copy Markdown for Report", command=copy_to_clipboard,
            bg="#0284c7", fg="#ffffff", font=(self.ui_font, 9, "bold"), relief="flat", padx=10, pady=4
        ).pack(side="right", padx=4)

        viewer = scrolledtext.ScrolledText(
            win, bg="#090d16", fg="#f8fafc", font=(self.mono_font, 10), wrap="word"
        )
        viewer.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        viewer.insert(tk.END, content)
        viewer.configure(state="disabled")

    def _browse_targets_file(self):
        chosen = filedialog.askopenfilename(
            title="Select Authorized Targets File",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if chosen:
            self.targets_file_var.set(chosen)

    def _clear_console(self):
        self.console.delete("1.0", tk.END)

    def _log(self, msg: str):
        self.log_queue.put(msg)

    def _poll_log_queue(self):
        while not self.log_queue.empty():
            msg = self.log_queue.get_nowait()
            self.console.insert(tk.END, msg)
            self.console.see(tk.END)
        self.root.after(80, self._poll_log_queue)

    def _platform_prefix(self) -> list[str]:
        exec_script = to_exec_path(SCRIPT_PATH)
        if os.name == "nt":
            prefix = ["wsl"]
            if self.root_mode_var.get():
                prefix.extend(["-u", "root"])
            prefix.extend(["--exec", "bash", exec_script])
            return prefix
        else:
            if self.root_mode_var.get() and hasattr(os, "geteuid") and os.geteuid() != 0:
                if shutil.which("pkexec"):
                    return ["pkexec", "bash", exec_script]
                return ["sudo", "bash", exec_script]
            return ["bash", exec_script]

    def _build_command(self) -> list[str]:
        target = self.target_var.get().strip()
        targets_file = self.targets_file_var.get().strip()
        mode = self.mode_var.get().strip()
        out_dir = self.active_session["path"]
        out_dir.mkdir(parents=True, exist_ok=True)

        exec_out = to_exec_path(out_dir)
        cmd = self._platform_prefix()

        if targets_file:
            cmd.extend(["--targets-file", to_exec_path(pathlib.Path(targets_file)), mode, "--output", exec_out])
        else:
            cmd.extend([target, mode, "--output", exec_out])

        if mode != "Dashboard":
            scope = self.scope_var.get()
            pval = self.port_val_var.get().strip()
            if scope == "All 65535 (-p-)":
                cmd.append("-p-")
            elif scope == "Top Ports (--top-ports)" and pval:
                cmd.extend(["--top-ports", pval])
            elif scope == "Custom Ports (-p)" and pval:
                cmd.extend(["-p", pval])

            profile = self.profile_var.get()
            if profile == "Fast (--fast)":
                cmd.append("--fast")
            elif profile == "Balanced":
                cmd.extend(["--profile", "balanced"])
            elif profile == "Stealth (-T2)":
                cmd.extend(["--profile", "stealth"])
            elif profile.startswith("-T"):
                cmd.append(profile)

            if self.run_recon_var.get():
                cmd.append("--run-recon")
                if self.parallel_recon_var.get():
                    cmd.append("--parallel-recon")
                if self.web_deep_var.get():
                    cmd.append("--web-deep")
                snmp = self.snmp_var.get().strip()
                if snmp:
                    cmd.extend(["--snmp-community", snmp])

            if self.fresh_var.get():
                cmd.append("--fresh")
            if self.no_ping_var.get():
                cmd.append("--no-ping")
            if self.intrusive_var.get():
                cmd.append("--intrusive")
            if self.dry_run_var.get():
                cmd.append("--dry-run")

        return cmd

    def _run_async_cmd(self, cmd: list[str], label: str, refresh_session_after: bool = False):
        if self.is_running:
            messagebox.showwarning("Busy", "A scan or test task is already running.")
            return
        self.is_running = True
        self.run_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.status_label.configure(text=f"Running: {label} ...")
        self._log(f"\n{'=' * 76}\n[LAUNCH] {' '.join(cmd)}\n{'=' * 76}\n")

        scan_session = self.active_session["path"]
        ai_enabled = self.ai_findings_var.get()
        ai_model = self.ai_model_var.get().strip() or "qwen3.5:9b"
        def worker():
            rc = -1
            try:
                creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
                self.proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    creationflags=creationflags,
                )
                assert self.proc.stdout is not None
                for line in self.proc.stdout:
                    self._log(line)
                self.proc.wait()
                rc = self.proc.returncode
                if refresh_session_after:
                    if rc == 0 and ai_enabled and "--dry-run" not in cmd:
                        from ai_advisor import update_session_findings
                        update_session_findings(scan_session, ai_model, self._log)
                    sm.build_session_enumeration_report(scan_session)
                    sm.update_all_sessions_index(SESSIONS_ROOT)
            except Exception as exc:
                self._log(f"\n[ERROR] {exc}\n")
            finally:
                self.proc = None
                self.root.after(0, lambda: self._on_finish(label, rc, refresh_session_after))

        threading.Thread(target=worker, daemon=True).start()

    def _on_finish(self, label: str, rc: int, refresh_session_after: bool = False):
        self.is_running = False
        self.run_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        if refresh_session_after:
            self.active_session = sm.get_active_session(SESSIONS_ROOT) or self.active_session
            self._refresh_session_banner()
            self._log(
                f"\n[REPORT UPDATED] Session Hub & Enumeration Report Draft updated for {self.active_session['session_id']}:\n"
                f"                 - {self.active_session['path'] / '00_SESSION_HUB.md'}\n"
                f"                 - {self.active_session['path'] / '02_ENUMERATION_REPORT_DRAFT.md'}\n"
            )
        status = "COMPLETED (Exit 0)" if rc == 0 else f"FINISHED WITH CODE {rc}"
        self.status_label.configure(text=f"{label}: {status}")
        self._log(f"\n[{status}] {label}\n")

    def start_scan(self):
        target = self.target_var.get().strip()
        targets_file = self.targets_file_var.get().strip()
        if not target and not targets_file:
            messagebox.showerror("Missing Target", "Please enter an authorized IPv4 address, /24 CIDR, or select a Targets File.")
            return
        cmd = self._build_command()
        label_target = f"file:{pathlib.Path(targets_file).name}" if targets_file else target
        self._run_async_cmd(
            cmd,
            f"[{self.active_session['session_id']}] Scan {label_target} ({self.mode_var.get()})",
            refresh_session_after=True,
        )

    def stop_process(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            self._log("\n[STOPPED] Process termination requested by user.\n")

    def run_dependency_check(self):
        exec_script = to_exec_path(SCRIPT_PATH)
        if os.name == "nt":
            cmd = ["wsl", "--exec", "bash", exec_script, "--check-deps"]
        else:
            cmd = ["bash", exec_script, "--check-deps"]
        self._run_async_cmd(cmd, "Dependency & Readiness Check")

    def run_qa_tests(self):
        cmd = [sys.executable, str(TEST_SUITE_PATH)]
        self._run_async_cmd(cmd, "Security QA Regression Test Suite")

    def launch_obsidian_direct(self):
        sdir = self.active_session["path"]
        sm.build_session_enumeration_report(sdir)
        sm.update_all_sessions_index(SESSIONS_ROOT)
        hub_file = sdir / "00_SESSION_HUB.md"
        uri = open_note_in_obsidian(hub_file, DEFAULT_SCANS_DIR)
        self._log(f"\n[OBSIDIAN] Opened Session Hub ({self.active_session['session_id']}) via {uri}\n")

    def open_dashboard_preview(self):
        target = self.target_var.get().strip()
        sdir = self.active_session["path"]
        sm.build_session_enumeration_report(sdir)
        sm.update_all_sessions_index(SESSIONS_ROOT)
        items = collect_available_dashboards(sdir, preferred_target=target)
        if not items:
            messagebox.showinfo(
                "No Dashboard Yet",
                f"No dashboards found yet in session {self.active_session['session_id']}.\nRun a scan first!"
            )
            return

        win = tk.Toplevel(self.root)
        win.title(f"Obsidian Dashboards — Active Session: {self.active_session['session_id']} ({self.active_session['name']})")
        win.geometry("1000x740")
        win.configure(bg="#0f172a")

        bar = ttk.Frame(win)
        bar.pack(fill="x", padx=12, pady=10)
        ttk.Label(bar, text="Select Session Note / Host Dashboard:", style="SubHeader.TLabel").pack(side="left", padx=(0, 8))

        labels = [label for label, _ in items]
        selected_var = tk.StringVar(value=labels[0])
        combo = ttk.Combobox(bar, textvariable=selected_var, values=labels, width=60, state="readonly")
        combo.pack(side="left", padx=(0, 10))

        viewer = scrolledtext.ScrolledText(
            win, bg="#090d16", fg="#f8fafc", font=(self.mono_font, 10), wrap="word"
        )
        viewer.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        def load_selected(*_args):
            idx = combo.current()
            if idx < 0:
                idx = 0
            path = items[idx][1]
            viewer.configure(state="normal")
            viewer.delete("1.0", tk.END)
            viewer.insert(tk.END, path.read_text(encoding="utf-8", errors="replace"))
            viewer.configure(state="disabled")

        def launch_current_in_obsidian():
            idx = combo.current()
            if idx < 0:
                idx = 0
            path = items[idx][1]
            uri = open_note_in_obsidian(path, DEFAULT_SCANS_DIR)
            self._log(f"\n[OBSIDIAN] Opened {path.name} via {uri}\n")

        combo.bind("<<ComboboxSelected>>", load_selected)

        tk.Button(
            bar, text="🚀 Open Selected in Obsidian App", command=launch_current_in_obsidian,
            bg="#9333ea", fg="#ffffff", font=(self.ui_font, 9, "bold"), relief="flat", padx=12, pady=5
        ).pack(side="right", padx=4)

        load_selected()

    def open_latest_html(self):
        target = self.target_var.get().strip().replace("/", "_")
        sdir = self.active_session["path"]
        search_root = sdir / target if (sdir / target).is_dir() else sdir
        htmls = sorted(search_root.rglob("*.html"), key=lambda p: p.stat().st_mtime, reverse=True)
        if not htmls:
            messagebox.showinfo("No HTML Reports", f"No rendered HTML reports found in session {self.active_session['session_id']} yet.")
            return
        webbrowser.open(htmls[0].resolve().as_uri())

    def open_output_folder(self):
        sdir = self.active_session["path"]
        sdir.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            os.startfile(str(sdir))
        else:
            subprocess.Popen(["xdg-open", str(sdir)])


def main():
    if "--open-obsidian" in sys.argv:
        sm.migrate_legacy_root_scans(DEFAULT_SCANS_DIR, SESSIONS_ROOT)
        active = sm.get_active_session(SESSIONS_ROOT)
        if active:
            sm.build_session_enumeration_report(active["path"])
            sm.update_all_sessions_index(SESSIONS_ROOT)
            uri = open_note_in_obsidian(active["path"] / "00_SESSION_HUB.md", DEFAULT_SCANS_DIR)
            print(f"Opened in Obsidian: {uri}")
        return
    root = tk.Tk()
    NmapObsidianGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
