using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Forms;

internal static class NmapDashboardLauncher
{
    private static string Quote(string value)
    {
        StringBuilder result = new StringBuilder("\"");
        int slashes = 0;
        foreach (char character in value)
        {
            if (character == '\\') { slashes++; continue; }
            if (character == '"')
            {
                result.Append('\\', slashes * 2 + 1);
                result.Append('"');
            }
            else
            {
                result.Append('\\', slashes);
                result.Append(character);
            }
            slashes = 0;
        }
        result.Append('\\', slashes * 2);
        return result.Append('"').ToString();
    }

    [STAThread]
    public static int Main(string[] args)
    {
        string folder = AppDomain.CurrentDomain.BaseDirectory;
        bool selfTest = Array.IndexOf(args, "--self-test") >= 0;
        string python = Path.Combine(folder, "runtime", selfTest ? "python.exe" : "pythonw.exe");
        string script = Path.Combine(folder, selfTest ? "packaging\\portable_self_test.py" : "portable_start.py");
        try
        {
            if (!File.Exists(python) || !File.Exists(script))
                throw new FileNotFoundException("Extract the entire ZIP before starting the dashboard. Keep runtime and the application files beside this executable.");
            StringBuilder arguments = new StringBuilder("-I ");
            arguments.Append(Quote(script));
            if (!selfTest)
                foreach (string argument in args) arguments.Append(' ').Append(Quote(argument));
            ProcessStartInfo start = new ProcessStartInfo(python, arguments.ToString());
            start.WorkingDirectory = folder;
            start.UseShellExecute = false;
            start.CreateNoWindow = true;
            start.WindowStyle = ProcessWindowStyle.Hidden;
            start.EnvironmentVariables["PYTHONDONTWRITEBYTECODE"] = "1";
            using (Process process = Process.Start(start))
            {
                if (selfTest) { process.WaitForExit(); return process.ExitCode; }
            }
            return 0;
        }
        catch (Exception error)
        {
            string message = "Unable to start Nmap Obsidian Dashboard.\n\n" + error.Message;
            try { File.WriteAllText(Path.Combine(folder, "startup-error.log"), error.ToString()); } catch { }
            if (!selfTest) MessageBox.Show(message, "Nmap Obsidian Dashboard", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 1;
        }
    }
}
