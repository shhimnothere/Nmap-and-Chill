"""Exercise the bundled runtime and GUI without creating real scan evidence."""
import json
import os
import pathlib
import sys
import tempfile
import traceback
from unittest.mock import patch

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.dont_write_bytecode = True
os.chdir(ROOT)
result = {'python': sys.version, 'runtime': sys.executable, 'checks': [], 'success': False}
try:
    import tkinter as tk
    import sqlite3
    import ssl
    import urllib.request
    import xml.etree.ElementTree
    import nmap_obsidian_gui as gui
    import session_manager
    import workstation_db
    import ai_advisor
    import advisor_history
    import peas_import
    import snmp_assessment
    import obsidian_setup
    result['checks'].append('Bundled standard library, Tk, SSL, SQLite and all application modules imported')
    with tempfile.TemporaryDirectory(prefix='nmap_portable_self_test_') as directory:
        scans = pathlib.Path(directory) / 'scans'
        root = tk.Tk()
        root.withdraw()
        with patch.object(gui, 'DEFAULT_SCANS_DIR', scans), patch.object(gui, 'SESSIONS_ROOT', scans / 'sessions'):
            app = gui.NmapObsidianGUI(root)
            app.target_var.set('192.0.2.150')
            assert (app._peas_target() / 'imports').is_dir()
            # Validate the new advisor target control against isolated evidence.
            (app.active_session['path'] / '192.0.2.150' / 'Runs').mkdir()
            ai_advisor.open_advisor(app)
            root.update_idletasks()
        root.destroy()
    result['checks'].append('Desktop GUI, session setup, PEAS import controls and AI advisor window initialized with temporary evidence only')
    for plugin in obsidian_setup.PLUGINS:
        assert (ROOT / 'obsidian_plugins' / plugin / 'main.js').exists()
    assert (ROOT / 'NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh').exists()
    result['checks'].append('Scan script and all three Obsidian viewer plugins present')
    result['success'] = True
except Exception:
    result['error'] = traceback.format_exc()
finally:
    (ROOT / 'package-self-test.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
raise SystemExit(0 if result['success'] else 1)
