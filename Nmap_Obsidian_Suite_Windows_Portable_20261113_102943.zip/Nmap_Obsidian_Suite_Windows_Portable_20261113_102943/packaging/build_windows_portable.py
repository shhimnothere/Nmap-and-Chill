"""Build a portable Windows folder/ZIP with an EXE launcher and private Python runtime."""
import datetime as dt
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
DIST = ROOT / 'dist'
MODULES = ('nmap_obsidian_gui.py', 'session_manager.py', 'workstation_db.py', 'ai_advisor.py', 'advisor_history.py', 'snmp_assessment.py', 'peas_import.py', 'obsidian_setup.py', 'portable_start.py')


def build():
    if os.name != 'nt':
        raise SystemExit('Build the Windows portable distribution using Windows Python with Tk installed.')
    stamp = dt.datetime.now().strftime('%Y%m%d_%H%M%S')
    name = 'Nmap_Obsidian_Suite_Windows_Portable_' + stamp
    output = DIST / name
    output.mkdir(parents=True, exist_ok=False)
    runtime = output / 'runtime'
    runtime.mkdir()
    installation = pathlib.Path(sys.base_prefix)
    for pattern in ('python.exe', 'pythonw.exe', 'python*.dll', 'vcruntime*.dll', 'LICENSE*'):
        for source in installation.glob(pattern):
            if source.is_file(): shutil.copy2(source, runtime / source.name)
    for directory in ('DLLs', 'Lib', 'tcl'):
        source = installation / directory
        if not source.is_dir():
            raise RuntimeError('Python runtime is missing ' + directory)
        shutil.copytree(source, runtime / directory, ignore=shutil.ignore_patterns('site-packages', '__pycache__', '*.pyc', '*.pyo', 'test', 'tests', 'ensurepip', 'idlelib', 'turtledemo'))
    # Isolated mode prevents installed packages and user environment overrides from changing this runtime.
    for name in MODULES:
        shutil.copy2(ROOT / name, output / name)
    shutil.copy2(ROOT / 'NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh', output)
    shutil.copy2(ROOT / 'README.md', output)
    for directory in ('tests', 'obsidian_plugins'):
        shutil.copytree(ROOT / directory, output / directory, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', 'data.json'))
    support = output / 'packaging'
    support.mkdir()
    for name in ('WindowsLauncher.cs', 'portable_self_test.py', 'build_windows_portable.py', 'build_linux_packages.py'):
        shutil.copy2(ROOT / 'packaging' / name, support / name)
    (output / 'scans').mkdir()
    linux = output / 'linux'
    linux.mkdir()
    for name in ('nmap-obsidian-suite_6.3.0_all.deb', 'nmap-obsidian-suite-6.3.0-linux-installer.tar.gz'):
        source = DIST / name
        if source.exists():shutil.copy2(source, linux / name)
    compiler = pathlib.Path(os.environ.get('WINDIR', 'C:/Windows')) / 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
    exe = output / 'Start_Nmap_Dashboard.exe'
    subprocess.run([str(compiler), '/nologo', '/target:winexe', '/platform:x64', '/optimize+', '/reference:System.Windows.Forms.dll', '/out:' + str(exe), str(support / 'WindowsLauncher.cs')], check=True)
    (output / 'Launch_Nmap_Dashboard.bat').write_text('@echo off\nstart "" "%~dp0Start_Nmap_Dashboard.exe"\n', encoding='ascii')
    (output / 'START_HERE.txt').write_text('''NMAP OBSIDIAN SUITE — WINDOWS PORTABLE

1. Extract the entire ZIP into a writable folder. Do not start the EXE from inside the ZIP.
2. Double-click Start_Nmap_Dashboard.exe.
3. Python and the dashboard libraries are included. No Python installation is required.
4. New evidence is saved under scans in this extracted folder.

REQUIRED EXTERNAL APPLICATIONS
- Windows 10/11 x64 with .NET Framework 4.x enabled (used by the small launcher).
- WSL with a Kali/Ubuntu distribution and Nmap/Python for network scanning.
  Use the dashboard Check Deps button to verify scan dependencies.
- Ollama running locally with qwen3.5:9b for AI explanations:
    ollama pull qwen3.5:9b
- Obsidian for the linked vault and viewers. The three viewer plugins are included.
  Community-plugin activation uses the Obsidian CLI; enable it in Obsidian Settings,
  General, Advanced, Command line interface. Reports remain readable without Obsidian.

The tool does not install WSL, configure targets, or run scans at startup.
The ZIP contains application code, runtime, documentation, tests, plugins and Linux packages.
Scan sessions, PEAS originals, credentials and personal Obsidian settings are not packaged.
Your previous evidence remains in the original workspace. Import evidence deliberately into
its intended target and session; do not copy an active-session pointer from another computer.

TROUBLESHOOTING
- Keep runtime, plugins and scripts beside the EXE.
- On startup errors read startup-error.log.
- Run Start_Nmap_Dashboard.exe --self-test to create package-self-test.json.
- The launcher is unsigned. Windows may require you to approve a downloaded executable.
- Use a writable directory; avoid Program Files and read-only network locations.

See README.md for PEAS imports, evidence protection and test-advisor behavior.
''',encoding='utf-8')
    print('Portable folder staged:', output, flush=True)
    test = subprocess.run([str(exe), '--self-test'], cwd=output, timeout=60)
    report = json.loads((output / 'package-self-test.json').read_text(encoding='utf-8'))
    if test.returncode or not report.get('success'):
        raise RuntimeError('Portable self-test failed: ' + json.dumps(report))
    print('Executable + isolated runtime self-test passed', flush=True)
    # Verify this is a clean application distribution, not an evidence export.
    assert not list((output / 'scans').iterdir())
    manifest = {}
    for path in sorted(output.rglob('*')):
        if path.is_file() and path.name not in ('SHA256_MANIFEST.json',):
            manifest[path.relative_to(output).as_posix()] = hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
    (output / 'SHA256_MANIFEST.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    archive = output.with_suffix('.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        for path in sorted(output.rglob('*')):
            bundle.write(path, path.relative_to(output.parent))
    with zipfile.ZipFile(archive) as bundle:
        bad = bundle.testzip()
        if bad: raise RuntimeError('ZIP integrity check failed: ' + bad)
    digest = hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest()
    archive.with_suffix('.zip.sha256').write_text(digest + '  ' + archive.name + '\n', encoding='ascii')
    print(json.dumps(dict(folder=str(output), archive=str(archive), size_mb=round(archive.stat().st_size / 1024**2, 1), sha256=digest, self_test=report['checks']), indent=2), flush=True)
    return output, archive

if __name__ == '__main__':
    build()
