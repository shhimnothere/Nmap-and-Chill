#!/usr/bin/env python3
"""
Builds installable Linux packages for NmapAutomator Kali Obsidian Dashboard Suite v6.3:
1. dist/nmap-obsidian-suite_6.3.0_all.deb (Debian / Kali Linux / Ubuntu / ParrotOS package)
2. dist/nmap-obsidian-suite-6.3.0-linux-installer.tar.gz (Universal Linux self-installer archive)
Also copies the built artifacts to C:\\Users\\titan5\\Downloads for easy transfer to any Linux machine.
"""

import os
import pathlib
import shutil
import subprocess
import tarfile
import tempfile


ROOT = pathlib.Path(__file__).resolve().parent.parent
DIST_DIR = ROOT / "dist"
DOWNLOADS_DIR = pathlib.Path(r"C:\Users\titan5\Downloads")
VERSION = "6.3.0"
PKG_NAME = "nmap-obsidian-suite"


def to_wsl_path(p: pathlib.Path) -> str:
    s = str(p.resolve())
    if os.name == "nt" and len(s) >= 2 and s[1] == ":":
        return f"/mnt/{s[0].lower()}{s[2:].replace(chr(92), '/')}"
    return s


def read_lf(path: pathlib.Path) -> bytes:
    return path.read_bytes().replace(b"\r\n", b"\n")


CLI_WRAPPER = b"""#!/usr/bin/env bash
exec /usr/bin/bash /usr/share/nmap-obsidian-suite/NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh "$@"
"""

GUI_WRAPPER = b"""#!/usr/bin/env bash
exec /usr/bin/python3 /usr/share/nmap-obsidian-suite/nmap_obsidian_gui.py "$@"
"""

QA_WRAPPER = b"""#!/usr/bin/env bash
exec /usr/bin/python3 /usr/share/nmap-obsidian-suite/tests/security_qa_regression.py "$@"
"""

DESKTOP_ENTRY = b"""[Desktop Entry]
Version=1.0
Type=Application
Name=Nmap Obsidian Dashboard
GenericName=Cyber Test Plan & Recon Suite
Comment=Authorized Nmap Enumeration, Multi-Service Recon & Obsidian Dashboard Generator (v6.3)
Exec=/usr/bin/nmap-obsidian-gui
Icon=nmap-obsidian-suite
Terminal=false
Categories=Security;Network;System;
Keywords=nmap;recon;obsidian;kali;security;enumeration;
StartupNotify=true
"""

SVG_ICON = b"""<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="128" height="128">
  <rect width="128" height="128" rx="24" fill="#0f172a"/>
  <circle cx="64" cy="64" r="46" fill="none" stroke="#38bdf8" stroke-width="4"/>
  <circle cx="64" cy="64" r="28" fill="none" stroke="#a855f7" stroke-width="3" stroke-dasharray="8 6"/>
  <circle cx="64" cy="64" r="8" fill="#38bdf8"/>
  <line x1="64" y1="64" x2="98" y2="34" stroke="#38bdf8" stroke-width="4" stroke-linecap="round"/>
  <circle cx="90" cy="42" r="5" fill="#22c55e"/>
</svg>
"""

BASH_COMPLETION = b"""# bash completion for nmap-obsidian
_nmap_obsidian_completions() {
    local cur prev modes opts
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    modes="Quick Basic UDP Full Vulns Recon All Dashboard"
    opts="--fast --profile --targets-file --run-recon --parallel-recon --web-deep --snmp-community --intrusive --no-ping --fresh --dry-run --check-deps -p- -p --top-ports -T2 -T3 -T4 -T5 --max-retries --min-rate --max-rate --host-timeout --output --max-hosts --no-markdown --no-html --help"

    if [[ $prev == "--profile" ]]; then
        COMPREPLY=( $(compgen -W "stealth balanced fast" -- "$cur") )
        return 0
    elif [[ $prev == "--targets-file" || $prev == "--output" ]]; then
        COMPREPLY=( $(compgen -f -- "$cur") )
        return 0
    fi

    if [[ $cur == -* ]]; then
        COMPREPLY=( $(compgen -W "$opts" -- "$cur") )
        return 0
    fi

    if (( COMP_CWORD == 2 )); then
        COMPREPLY=( $(compgen -W "$modes" -- "$cur") )
        return 0
    fi
}
complete -F _nmap_obsidian_completions nmap-obsidian NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh
"""

ZSH_COMPLETION = b"""#compdef nmap-obsidian NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh
_nmap_obsidian() {
  local -a modes
  modes=(
    'Quick:Scan default TCP ports'
    'Basic:Quick discovery + service/version scan'
    'UDP:Scan default UDP ports and open UDP services'
    'Full:Scan all 65535 TCP ports + service scan'
    'Vulns:Non-intrusive NSE vulnerability & CVE scan'
    'Recon:Generate or run service-specific enumeration'
    'All:Full assessment workflow'
    'Dashboard:Refresh Obsidian dashboard without network traffic'
  )
  _arguments \\
    '1:target IPv4 or /24 CIDR:_files' \\
    '2:scan mode:((${modes}))' \\
    '--fast[High-efficiency lab/internal tuning]' \\
    '--profile[Speed profile]:profile:(stealth balanced fast)' \\
    '--targets-file[Authorized targets list file]:file:_files' \\
    '--run-recon[Execute allowlisted recon probes]' \\
    '--parallel-recon[Run lightweight recon probes in parallel]' \\
    '--web-deep[Run Nikto and Gobuster deep web checks]' \\
    '--snmp-community[Authorized SNMP community string]:community:' \\
    '--fresh[Force new scan ignoring cache]' \\
    '--no-ping[Treat host as up (-Pn)]' \\
    '--intrusive[Allow intrusive NSE vuln scripts]' \\
    '--dry-run[Validate and print commands without network traffic]' \\
    '--check-deps[Verify installed dependencies]' \\
    '--output[Output directory]:dir:_files -/'
}
_nmap_obsidian "$@"
"""

DEBIAN_CONTROL = f"""Package: {PKG_NAME}
Version: {VERSION}
Section: security
Priority: optional
Architecture: all
Depends: bash (>= 4.0), nmap, python3, xsltproc, curl
Recommends: python3-tk, sslscan, smbclient, bind9-dnsutils | dnsutils, snmp, nikto, gobuster, dirb
Maintainer: Cyber Test Plan Engineering <security-qa@local>
Description: NmapAutomator v6.3 Kali & Obsidian Cyber Test Plan Suite
 High-efficiency authorized network reconnaissance, multi-service enumeration,
 HTML report renderer, Obsidian Markdown dashboard generator, cross-platform
 Desktop GUI launcher, and 14-point Security QA Regression Test Suite.
""".encode("utf-8")

DEBIAN_POSTINST = b"""#!/usr/bin/env bash
set -e
if [[ -d /usr/share/dirb/wordlists && ! -e /usr/share/wordlists/dirb ]]; then
  mkdir -p /usr/share/wordlists
  ln -sfn /usr/share/dirb/wordlists /usr/share/wordlists/dirb || true
fi
chmod 0755 /usr/share/nmap-obsidian-suite/NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh
chmod 0755 /usr/share/nmap-obsidian-suite/nmap_obsidian_gui.py
chmod 0755 /usr/share/nmap-obsidian-suite/tests/security_qa_regression.py
chmod 0755 /usr/bin/nmap-obsidian /usr/bin/nmap-obsidian-gui /usr/bin/nmap-obsidian-qa

# Place a clickable Desktop icon for the invoking sudo user if ~/Desktop exists
if [[ -n ${SUDO_USER:-} && $SUDO_USER != root ]]; then
  USER_HOME=$(getent passwd "$SUDO_USER" | cut -d: -f6 || true)
  if [[ -n $USER_HOME && -d "$USER_HOME/Desktop" ]]; then
    cp -f /usr/share/applications/nmap-obsidian-suite.desktop "$USER_HOME/Desktop/nmap-obsidian-suite.desktop"
    chmod 0755 "$USER_HOME/Desktop/nmap-obsidian-suite.desktop"
    chown "$SUDO_USER:$SUDO_USER" "$USER_HOME/Desktop/nmap-obsidian-suite.desktop" 2>/dev/null || true
    # Mark trusted on XFCE/GNOME (Kali/Ubuntu) if gio is present
    su - "$SUDO_USER" -c "gio set '$USER_HOME/Desktop/nmap-obsidian-suite.desktop' metadata::trusted true" 2>/dev/null || true
  fi
fi
exit 0
"""

UNIVERSAL_INSTALLER_SH = b"""#!/usr/bin/env bash
# Universal Linux Installer for NmapAutomator Kali Obsidian Dashboard Suite v6.3
set -Eeuo pipefail

if (( EUID != 0 )); then
  echo "Please run with sudo: sudo ./install-linux.sh" >&2
  exit 1
fi

HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
echo "=== Installing NmapAutomator Kali Obsidian Dashboard Suite v6.3 ==="

if command -v apt-get >/dev/null 2>&1; then
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -y
  apt-get install -y nmap python3 python3-tk xsltproc curl sslscan smbclient bind9-dnsutils snmp nikto gobuster dirb || true
elif command -v dnf >/dev/null 2>&1; then
  dnf install -y nmap python3 python3-tkinter libxslt curl sslscan samba-client bind-utils net-snmp-utils nikto gobuster || true
elif command -v pacman >/dev/null 2>&1; then
  pacman -Sy --noconfirm nmap python tk libxslt curl sslscan smbclient bind net-snmp nikto gobuster || true
fi

install -d -m 0755 /usr/share/nmap-obsidian-suite/tests
install -m 0755 "$HERE/NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh" /usr/share/nmap-obsidian-suite/NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh
install -m 0755 "$HERE/nmap_obsidian_gui.py" /usr/share/nmap-obsidian-suite/nmap_obsidian_gui.py
install -m 0755 "$HERE/session_manager.py" /usr/share/nmap-obsidian-suite/session_manager.py
install -m 0644 "$HERE/ai_advisor.py" /usr/share/nmap-obsidian-suite/ai_advisor.py
install -m 0644 "$HERE/obsidian_setup.py" /usr/share/nmap-obsidian-suite/obsidian_setup.py
install -m 0644 "$HERE/snmp_assessment.py" /usr/share/nmap-obsidian-suite/snmp_assessment.py
install -m 0644 "$HERE/tests/test_advisor_history.py" /usr/share/nmap-obsidian-suite/tests/test_advisor_history.py
install -m 0644 "$HERE/advisor_history.py" /usr/share/nmap-obsidian-suite/advisor_history.py
install -m 0644 "$HERE/peas_import.py" /usr/share/nmap-obsidian-suite/peas_import.py
install -m 0644 "$HERE/README.md" /usr/share/nmap-obsidian-suite/README.md
install -m 0644 "$HERE/tests/test_peas_import.py" /usr/share/nmap-obsidian-suite/tests/test_peas_import.py
cp -R "$HERE/obsidian_plugins" /usr/share/nmap-obsidian-suite/
install -m 0755 "$HERE/tests/security_qa_regression.py" /usr/share/nmap-obsidian-suite/tests/security_qa_regression.py

install -m 0755 "$HERE/bin/nmap-obsidian" /usr/bin/nmap-obsidian
install -m 0755 "$HERE/bin/nmap-obsidian-gui" /usr/bin/nmap-obsidian-gui
install -m 0755 "$HERE/bin/nmap-obsidian-qa" /usr/bin/nmap-obsidian-qa

install -d -m 0755 /usr/share/applications
install -m 0644 "$HERE/share/nmap-obsidian-suite.desktop" /usr/share/applications/nmap-obsidian-suite.desktop

install -d -m 0755 /usr/share/icons/hicolor/scalable/apps
install -m 0644 "$HERE/share/nmap-obsidian-suite.svg" /usr/share/icons/hicolor/scalable/apps/nmap-obsidian-suite.svg

install -d -m 0755 /usr/share/bash-completion/completions
install -m 0644 "$HERE/share/nmap-obsidian.bash" /usr/share/bash-completion/completions/nmap-obsidian

install -d -m 0755 /usr/share/zsh/vendor-completions
install -m 0644 "$HERE/share/_nmap-obsidian" /usr/share/zsh/vendor-completions/_nmap-obsidian

if [[ -d /usr/share/dirb/wordlists && ! -e /usr/share/wordlists/dirb ]]; then
  mkdir -p /usr/share/wordlists
  ln -sfn /usr/share/dirb/wordlists /usr/share/wordlists/dirb || true
fi

if [[ -n ${SUDO_USER:-} && $SUDO_USER != root ]]; then
  USER_HOME=$(getent passwd "$SUDO_USER" | cut -d: -f6 || true)
  if [[ -n $USER_HOME && -d "$USER_HOME/Desktop" ]]; then
    cp -f /usr/share/applications/nmap-obsidian-suite.desktop "$USER_HOME/Desktop/nmap-obsidian-suite.desktop"
    chmod 0755 "$USER_HOME/Desktop/nmap-obsidian-suite.desktop"
    chown "$SUDO_USER:$SUDO_USER" "$USER_HOME/Desktop/nmap-obsidian-suite.desktop" 2>/dev/null || true
  fi
fi

echo ""
echo "Installation complete!"
echo "  - CLI Scanner:        nmap-obsidian <IP-or-CIDR> <Mode> [--fast] [--run-recon]"
echo "  - Desktop GUI:        nmap-obsidian-gui (or click 'Nmap Obsidian Dashboard' on Desktop/App Menu)"
echo "  - Security QA Suite:  nmap-obsidian-qa"
echo "  - Readiness Check:    nmap-obsidian --check-deps"
"""


def write_lf_file(path: pathlib.Path, content: bytes):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content.replace(b"\r\n", b"\n"))


def build_packages():
    DIST_DIR.mkdir(parents=True, exist_ok=True)
    main_sh = read_lf(ROOT / "NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh")
    gui_py = read_lf(ROOT / "nmap_obsidian_gui.py")
    sess_py = read_lf(ROOT / "session_manager.py")
    advisor_py = read_lf(ROOT / "ai_advisor.py")
    setup_py = read_lf(ROOT / "obsidian_setup.py")
    snmp_py = read_lf(ROOT / "snmp_assessment.py")
    peas_py = read_lf(ROOT / "peas_import.py")
    history_py = read_lf(ROOT / "advisor_history.py")
    history_tests = read_lf(ROOT / "tests/test_advisor_history.py")
    peas_tests = read_lf(ROOT / "tests/test_peas_import.py")
    readme = read_lf(ROOT / "README.md")
    qa_py = read_lf(ROOT / "tests" / "security_qa_regression.py")

    # Ensure workspace and Downloads scripts also have pure LF line endings
    (ROOT / "NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh").write_bytes(main_sh)
    if DOWNLOADS_DIR.is_dir():
        (DOWNLOADS_DIR / "NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh").write_bytes(main_sh)

    with tempfile.TemporaryDirectory(prefix="nmap_pkg_build_") as tmp:
        tmp_path = pathlib.Path(tmp)

        # 1. Stage Debian package structure
        deb_root = tmp_path / f"{PKG_NAME}_{VERSION}_all"
        write_lf_file(deb_root / "DEBIAN" / "control", DEBIAN_CONTROL)
        write_lf_file(deb_root / "DEBIAN" / "postinst", DEBIAN_POSTINST)

        write_lf_file(deb_root / "usr" / "share" / PKG_NAME / "NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh", main_sh)
        write_lf_file(deb_root / "usr" / "share" / PKG_NAME / "nmap_obsidian_gui.py", gui_py)
        write_lf_file(deb_root / "usr" / "share" / PKG_NAME / "session_manager.py", sess_py)
        write_lf_file(deb_root / "usr" / "share" / PKG_NAME / "ai_advisor.py", advisor_py)
        write_lf_file(deb_root / "usr" / "share" / PKG_NAME / "obsidian_setup.py", setup_py)
        write_lf_file(deb_root / "usr" / "share" / PKG_NAME / "snmp_assessment.py", snmp_py)
        write_lf_file(deb_root / "usr" / "share" / PKG_NAME / "peas_import.py", peas_py)
        write_lf_file(deb_root / "usr" / "share" / PKG_NAME / "advisor_history.py", history_py)
        write_lf_file(deb_root / "usr" / "share" / PKG_NAME / "tests/test_advisor_history.py", history_tests)
        write_lf_file(deb_root / "usr" / "share" / PKG_NAME / "tests/test_peas_import.py", peas_tests)
        write_lf_file(deb_root / "usr" / "share" / PKG_NAME / "README.md", readme)
        shutil.copytree(ROOT / "obsidian_plugins", deb_root / "usr" / "share" / PKG_NAME / "obsidian_plugins")
        write_lf_file(deb_root / "usr" / "share" / PKG_NAME / "tests" / "security_qa_regression.py", qa_py)

        write_lf_file(deb_root / "usr" / "bin" / "nmap-obsidian", CLI_WRAPPER)
        write_lf_file(deb_root / "usr" / "bin" / "nmap-obsidian-gui", GUI_WRAPPER)
        write_lf_file(deb_root / "usr" / "bin" / "nmap-obsidian-qa", QA_WRAPPER)

        write_lf_file(deb_root / "usr" / "share" / "applications" / "nmap-obsidian-suite.desktop", DESKTOP_ENTRY)
        write_lf_file(deb_root / "usr" / "share" / "icons" / "hicolor" / "scalable" / "apps" / "nmap-obsidian-suite.svg", SVG_ICON)
        write_lf_file(deb_root / "usr" / "share" / "bash-completion" / "completions" / "nmap-obsidian", BASH_COMPLETION)
        write_lf_file(deb_root / "usr" / "share" / "zsh" / "vendor-completions" / "_nmap-obsidian", ZSH_COMPLETION)

        deb_out = DIST_DIR / f"{PKG_NAME}_{VERSION}_all.deb"

        # Build .deb inside WSL Linux filesystem so permissions (0755 on DEBIAN/postinst) are exact
        wsl_deb_stage = to_wsl_path(deb_root)
        wsl_deb_out = to_wsl_path(deb_out)
        wsl_build_cmd = (
            f"rm -rf /tmp/deb_build && cp -r '{wsl_deb_stage}' /tmp/deb_build && "
            f"chmod 0755 /tmp/deb_build/DEBIAN /tmp/deb_build/DEBIAN/postinst "
            f"/tmp/deb_build/usr/bin/* /tmp/deb_build/usr/share/{PKG_NAME}/*.sh "
            f"/tmp/deb_build/usr/share/{PKG_NAME}/*.py /tmp/deb_build/usr/share/{PKG_NAME}/tests/*.py && "
            f"chmod 0644 /tmp/deb_build/DEBIAN/control && "
            f"dpkg-deb --build --root-owner-group /tmp/deb_build '{wsl_deb_out}' && "
            f"rm -rf /tmp/deb_build"
        )
        res = subprocess.run(["wsl", "-u", "root", "--exec", "bash", "-c", wsl_build_cmd], capture_output=True, text=True)
        if res.returncode != 0:
            raise RuntimeError(f"dpkg-deb build failed:\n{res.stdout}\n{res.stderr}")
        print(f"[OK] Built Debian/Kali/Ubuntu package: {deb_out} ({deb_out.stat().st_size} bytes)")

        # 2. Build Universal Linux .tar.gz Installer Bundle
        tar_stage = tmp_path / f"{PKG_NAME}-{VERSION}-linux"
        write_lf_file(tar_stage / "install-linux.sh", UNIVERSAL_INSTALLER_SH)
        write_lf_file(tar_stage / "NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh", main_sh)
        write_lf_file(tar_stage / "nmap_obsidian_gui.py", gui_py)
        write_lf_file(tar_stage / "session_manager.py", sess_py)
        write_lf_file(tar_stage / "ai_advisor.py", advisor_py)
        write_lf_file(tar_stage / "obsidian_setup.py", setup_py)
        write_lf_file(tar_stage / "snmp_assessment.py", snmp_py)
        write_lf_file(tar_stage / "peas_import.py", peas_py)
        write_lf_file(tar_stage / "advisor_history.py", history_py)
        write_lf_file(tar_stage / "tests/test_advisor_history.py", history_tests)
        write_lf_file(tar_stage / "tests/test_peas_import.py", peas_tests)
        write_lf_file(tar_stage / "README.md", readme)
        shutil.copytree(ROOT / "obsidian_plugins", tar_stage / "obsidian_plugins")
        write_lf_file(tar_stage / "tests" / "security_qa_regression.py", qa_py)
        write_lf_file(tar_stage / "bin" / "nmap-obsidian", CLI_WRAPPER)
        write_lf_file(tar_stage / "bin" / "nmap-obsidian-gui", GUI_WRAPPER)
        write_lf_file(tar_stage / "bin" / "nmap-obsidian-qa", QA_WRAPPER)
        write_lf_file(tar_stage / "share" / "nmap-obsidian-suite.desktop", DESKTOP_ENTRY)
        write_lf_file(tar_stage / "share" / "nmap-obsidian-suite.svg", SVG_ICON)
        write_lf_file(tar_stage / "share" / "nmap-obsidian.bash", BASH_COMPLETION)
        write_lf_file(tar_stage / "share" / "_nmap-obsidian", ZSH_COMPLETION)

        tar_out = DIST_DIR / f"{PKG_NAME}-{VERSION}-linux-installer.tar.gz"

        def reset_tarinfo(ti: tarfile.TarInfo) -> tarfile.TarInfo:
            ti.uid = 0
            ti.gid = 0
            ti.uname = "root"
            ti.gname = "root"
            if ti.isdir() or ti.name.endswith((".sh", ".py", "nmap-obsidian", "nmap-obsidian-gui", "nmap-obsidian-qa")):
                ti.mode = 0o755
            else:
                ti.mode = 0o644
            return ti

        with tarfile.open(tar_out, "w:gz") as tf:
            tf.add(tar_stage, arcname=f"{PKG_NAME}-{VERSION}-linux", filter=reset_tarinfo)
        print(f"[OK] Built Universal Linux installer tarball: {tar_out} ({tar_out.stat().st_size} bytes)")

        if DOWNLOADS_DIR.is_dir():
            shutil.copy2(deb_out, DOWNLOADS_DIR / deb_out.name)
            shutil.copy2(tar_out, DOWNLOADS_DIR / tar_out.name)
            print(f"[OK] Copied Linux packages to {DOWNLOADS_DIR}")


if __name__ == "__main__":
    build_packages()
