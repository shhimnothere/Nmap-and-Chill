"""PEASS-ng evidence ingestion. Reads files only; no commands from evidence are executed."""
from __future__ import annotations
import argparse
import contextlib
import datetime as dt
import hashlib
import ipaddress
import json
import os
import pathlib
import re
import shutil
import subprocess
import tempfile
import time
from urllib.parse import quote

VERSION = 1
EXTENSIONS = {'.txt', '.log', '.out', '.ansi'}
BEGIN = '<!-- BEGIN PEAS GENERATED -->'
END = '<!-- END PEAS GENERATED -->'
SEVERITIES = ('Critical', 'High', 'Medium', 'Low', 'Informational')
CLASSIFICATIONS = ('Confirmed configuration weakness', 'Potential vulnerability requiring validation', 'Informational discovery', 'False positive or dismissed finding')
STATES = ('Needs Action', 'In Progress', 'Completed', 'Dismissed', 'Reviewed')
ANSI = re.compile(r'\x1b(?:\][^\x07]*(?:\x07|\x1b\\)|\[[0-?]*[ -/]*[@-~])')
SECRET = re.compile(r'''(?ix)((?:--?)?(?:password|passwd|pwd|token|secret|api[_-]?key|access[_-]?key|connectionstring)\s*[=:]\s*|--(?:password|token|secret)\s+)(?:"[^"]*"|'[^']*'|[^\s,;<>]+)''')


def redact(text):
    text = SECRET.sub(lambda m: m.group(1) + '[REDACTED]', text)
    text = re.sub(r'(?i)(://[^\s/:]+:)[^\s/@]+(@)', r'\1[REDACTED]\2', text)
    text = re.sub(r'(?i)(authorization:\s*(?:bearer|basic)\s+)\S+', r'\1[REDACTED]', text)
    text = re.sub(r'(?s)-----BEGIN [^-]*PRIVATE KEY-----.*?(?:-----END [^-]*PRIVATE KEY-----|$)', '[REDACTED PRIVATE KEY]', text)
    text = re.sub(r'(?i)\b(?:AKIA|ASIA)[A-Z0-9]{16}\b', '[REDACTED ACCESS KEY]', text)
    text = re.sub(r'(?i)([^\s:]+:\d+:)[a-f0-9]{32}:[a-f0-9]{32}', r'\1[REDACTED HASHES]', text)
    return text


def now():
    return dt.datetime.now().astimezone().isoformat(timespec='seconds')


def atomic(path, content):
    path = pathlib.Path(path)
    for ancestor in (path, *path.parents):
        if ancestor.is_symlink() or (hasattr(ancestor, 'is_junction') and ancestor.is_junction()):
            raise ValueError('Refusing linked evidence output: ' + str(path))
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise ValueError('Refusing linked output: ' + str(path))
    data = content.encode('utf-8') if isinstance(content, str) else content
    fd, name = tempfile.mkstemp(dir=path.parent, prefix='.peas-')
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def load(path, default):
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default


def dump(path, obj):
    atomic(path, json.dumps(obj, indent=2, ensure_ascii=False) + '\n')


def contained(root, path):
    root, path = pathlib.Path(root).resolve(), pathlib.Path(path)
    if path.is_symlink() or any(p.is_symlink() or (hasattr(p, 'is_junction') and p.is_junction()) for p in (path, *path.parents) if p != root and p.is_relative_to(root)) or not path.resolve().is_relative_to(root):
        raise ValueError('Unsafe evidence path: ' + str(path))
    return path


@contextlib.contextmanager
def target_lock(target):
    lock = target / '.peas.lock'
    try:
        lock.mkdir()
    except FileExistsError:
        raise RuntimeError('PEAS import already running (if interrupted, verify no importer is active before removing .peas.lock)')
    try:
        yield
    finally:
        lock.rmdir()


def protect(path):
    """Protect private snapshots. Never silently claim Windows ACLs succeeded."""
    is_drvfs = os.name != 'nt' and bool(re.match(r'^/mnt/[a-z]/', str(path.resolve()))) and shutil.which('icacls.exe') and shutil.which('whoami.exe')
    if os.name == 'nt' or is_drvfs:
        command = 'whoami.exe' if is_drvfs else 'whoami'
        owner = subprocess.run([command, '/user', '/fo', 'csv', '/nh'], capture_output=True, text=True, check=True).stdout
        sid = re.search(r'S-1-5-[0-9-]+', owner).group()
        native_path = subprocess.run(['wslpath', '-w', str(path)], capture_output=True, text=True, check=True).stdout.strip() if is_drvfs else str(path)
        result = subprocess.run(['icacls.exe' if is_drvfs else 'icacls', native_path, '/inheritance:r', '/grant:r', '*' + sid + ':(OI)(CI)F', '*S-1-5-18:(OI)(CI)F'], capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError('Unable to restrict evidence ACL: ' + result.stderr)
    else:
        path.chmod(0o700 if path.is_dir() else 0o600)


# Each rule requires a section plus an observed configuration, not a color or keyword score.
# Output classification remains provisional even when a configuration line is explicit.
LINUX = [
 ('identity', r'user|group|basic information|system information', r'(?:uid=\d+|gid=\d+|groups=|^user\s*:)', 'Current user and groups', 'Informational', 'Review group membership and privilege boundaries', 'Remove unnecessary privileged memberships.'),
 ('host', r'os|kernel|system information|basic information', r'(?:Linux\s+\S+|Ubuntu|Debian|CentOS|architecture\s*:|kernel\s*:|OS\s*:)', 'Linux host and kernel inventory', 'Informational', 'Verify OS, kernel and package versions against the asset baseline', 'Maintain supported OS and package versions.'),
 ('sudo', r'sudo', r'(?:NOPASSWD|\(ALL[^)]*\)\s*(?:ALL|/)|sudo\s+.*(?:ALL|/))', 'Potential excessive sudo privileges', 'High', 'Review effective sudo policy and permitted arguments; verify authorization without invoking a privileged payload', 'Restrict sudo commands, users and arguments; require authentication where feasible.'),
 ('suid', r'suid|sgid', r'(?:-[rwxSs-]{9}.*\s/|/\S+)', 'SUID or SGID executable requires review', 'Medium', 'Inspect owner, mode, package provenance and permitted behavior of this executable', 'Remove unnecessary SUID/SGID bits and repair package permissions.'),
 ('capabilities', r'capabilit', r'(?:cap_[a-z_]+(?:[,+=]|\s)|=\s*ep)', 'Executable Linux capabilities require review', 'Medium', 'Verify effective capabilities and ownership; assess whether privileges exceed the executable requirement', 'Remove unnecessary file capabilities and prevent unprivileged modification.'),
 ('writable', r'writ|permission', r'(?:writable\s*[:=].*(?:true|yes|/)|(?:world.writable|other writable)|^/[\w./-]+)', 'Potential writable sensitive path', 'Medium', 'Inspect the path ACL, owner and actual privileged consumers before assigning impact', 'Limit write access to authorized service or administrative accounts.'),
 ('scheduled', r'cron|timer|scheduled', r'(?:\*\s+\*|/etc/cron|\.timer\b|ExecStart=|writable.*(?:true|yes))', 'Scheduled execution configuration', 'Low', 'Confirm execution user, executable path, writable parents and schedule', 'Use fixed executable paths and restrict writes to privileged scheduled content.'),
 ('process', r'process|service', r'(?:^root\s+\d+|systemd|ExecStart=|/usr/\S+)', 'Running process or service inventory', 'Informational', 'Correlate process identity and listening service with Nmap inventory', 'Run services with the least privilege required.'),
 ('environment', r'environment|path', r'(?:^PATH=|^LD_PRELOAD=|^LD_LIBRARY_PATH=|PATH.*(?:writable|\.\:|:\.))', 'Environment or executable search path requires review', 'Medium', 'Check inherited environment and each search directory ownership in the privileged execution context', 'Remove relative or writable entries from privileged execution search paths.'),
 ('vulnerability', r'kernel|package|vulnerab|exploit', r'(?:CVE-\d{4}-\d{4,}|vulnerable\s*[:=]\s*(?:yes|true))', 'Kernel or package vulnerability indicator', 'Medium', 'Verify exact installed build and vendor patch/backport status; treat suggested CVEs as unverified', 'Apply vendor-supported security updates after applicability review.'),
 ('container', r'docker|container|namespace', r'(?:docker\.sock|privileged\s*[:=]\s*true|docker\s+group|uid_map|cap_sys_admin)', 'Container privilege boundary requires review', 'Medium', 'Check container capabilities, socket access and namespace mappings in the actual user context', 'Restrict engine socket access and privileged containers; isolate namespaces.'),
 ('sharing', r'nfs|exports|sharing', r'(?:no_root_squash|insecure|\(rw[,)]|/etc/exports)', 'NFS or file-sharing configuration requires review', 'Medium', 'Verify export client restrictions, identity mapping and write permissions', 'Use narrow client allowlists, root squashing and minimum necessary write access.'),
]
WINDOWS = [
 ('host', r'os|system|basic|hotfix', r'(?:Windows\s+\S+|OS\s*(?:Name|Version)|Build\s*[:=]|Architecture\s*[:=]|KB\d{5,})', 'Windows version and patch inventory', 'Informational', 'Verify OS build and installed updates against the asset baseline', 'Maintain supported builds and approved updates.'),
 ('identity', r'user|group|token|privileg', r'(?:S-1-5-|BUILTIN\\|\\Administrators|Se\w+Privilege|User\s*Name\s*:)', 'Windows identity, groups and token privileges', 'Medium', 'Verify group/token membership, enabled state and whether the current token is elevated', 'Remove unnecessary rights and administrative memberships.'),
 ('uac', r'uac|registry', r'(?:EnableLUA\s*[:=]\s*0|ConsentPromptBehaviorAdmin\s*[:=]\s*0|LocalAccountTokenFilterPolicy\s*[:=]\s*1)', 'Potential weakened UAC configuration', 'Medium', 'Verify effective UAC policy and token context; this output does not demonstrate a bypass', 'Apply the approved UAC baseline.'),
 ('service_permissions', r'service|permission', r'(?:SERVICE_(?:ALL_ACCESS|CHANGE_CONFIG)|WRITE_DAC|WRITE_OWNER|(?:Everyone|BUILTIN\\Users).*(?:FullControl|Modify|Write|\(F\)|\(M\))|writable\s*[:=]\s*(?:true|yes))', 'Potential writable privileged service', 'High', 'Verify effective service/file ACL for the current user and service execution identity', 'Restrict service configuration and binary-directory modification rights.'),
 ('unquoted', r'unquoted|service', r'(?:unquoted\s*[:=]\s*(?:true|yes)|^[A-Z]:\\Program Files\\[^"\r\n]+\.exe)', 'Potential unquoted service executable path', 'Medium', 'Check whether the service path is unquoted, executes with privilege, and has a writable earlier path component', 'Quote service executable paths and restrict writable parent directories.'),
 ('scheduled', r'scheduled|task', r'(?:Run As\s*:|Task To Run\s*:|writable\s*[:=]\s*(?:true|yes)|HighestAvailable)', 'Scheduled task privilege configuration', 'Medium', 'Verify task principal, action, triggers and effective task/binary permissions', 'Limit task editing and executable modification; use least privilege.'),
 ('registry', r'registry|autologon|autorun', r'(?:AutoAdminLogon\s*[:=]\s*1|AlwaysInstallElevated\s*[:=]\s*(?:1|0x1)|HK(?:LM|CU).*\(F\))', 'Registry privilege or credential configuration indicator', 'High', 'For AlwaysInstallElevated verify BOTH machine and user policy; inspect effective registry ACLs and policy', 'Disable AlwaysInstallElevated in both hives and restrict sensitive registry writes.'),
 ('dll', r'dll|path|permission', r'(?:DLL.*(?:writable|hijack)|PATH.*writable|SafeDllSearchMode\s*[:=]\s*0)', 'Potential DLL search-order risk', 'Medium', 'Verify actual DLL loading order, writable search locations and privileged consumer', 'Use fully qualified library paths and restrict writes to search directories.'),
 ('security', r'antivirus|defender|security product|firewall', r'(?:Defender|EDR|Antivirus|RealTimeProtection\s*[:=]|Firewall.*(?:False|Disabled))', 'Security product configuration inventory', 'Informational', 'Validate reported protection state against management telemetry; no evasion testing is implied', 'Maintain the approved monitoring and endpoint protection baseline.'),
]


def parse(data, target, digest):
    text = ANSI.sub('', data.decode('utf-8-sig', errors='replace')).replace('\r\n', '\n').replace('\r', '\n')
    if not text.strip():
        raise ValueError('Empty evidence file')
    tools = [name for name in ('LinPEAS', 'WinPEAS') if re.search(name, text, re.I)]
    if len(tools) != 1:
        raise ValueError('Evidence must identify exactly one PEASS tool in its contents')
    tool = tools[0]
    warnings = []
    if '\ufffd' in text:
        warnings.append('Invalid UTF-8 replaced in parsing; protected original retained')
    if not re.search(r'(?:peas.*(?:finished|completed|end)|(?:finished|completed).*peas|end of.*peas)', text, re.I):
        warnings.append('No completion marker detected; output may be partial or this PEASS version may omit an end marker')
    if not data.endswith((b'\n', b'\r')):
        warnings.append('No final newline; possibly truncated')
    section = 'Unsectioned'
    findings, sections = [], []
    rules = LINUX if tool == 'LinPEAS' else WINDOWS
    for number, line in enumerate(text.splitlines(), 1):
        stripped = line.strip()
        # PEASS Unicode box headings and common exported Markdown headings.
        heading = re.match(r'^(?:[╔╚╠═─━▓▒░│┃┌└├┼+*#=-]{2,}\s*|\[\+\]\s*)([^\n]{3,160})', stripped)
        if heading:
            section = heading.group(1).strip(' ═─━╔╗╚╝│┃*-#=')
            sections.append(section)
        if not stripped or heading:
            continue
        matches = [(r, False) for r in rules if re.search(r[1], section, re.I) and re.search(r[2], stripped, re.I)]
        # Secret rules require a credential-context value rather than just a heading.
        credential = redact(stripped) != stripped or bool(re.search(r'(?i)(?:credential manager|cmdkey|password file|credential file|SAM hive|/etc/shadow|id_rsa)', stripped) and re.search(r'(?i)credential|password|secret|artifact|file', section))
        if credential:
            matches.append((('credential', '.', '.', 'Potential credential or password artifact exposure', 'High', 'Validate access and context without reusing any discovered credential; preserve restricted original evidence', 'Restrict access, remove unnecessary secrets, and rotate credentials after exposure is validated.'), True))
        for rule, is_secret in matches:
            category, _, _, title, severity, validation, mitigation = rule
            ident = 'PEAS-' + hashlib.sha256((target + digest + category + str(number)).encode()).hexdigest()[:16]
            excerpt = redact(stripped)
            findings.append(dict(id=ident, target=target, source_tool=tool, title=title, description=f'{section}: {excerpt}', category=category,
                severity=severity, confidence='High' if severity == 'Informational' else 'Medium', evidence_excerpt=excerpt,
                source_hash=digest, line_start=number, line_end=number, source_section=redact(section),
                validation_status='Reviewed' if severity == 'Informational' else 'Needs Action',
                classification='Informational discovery' if severity == 'Informational' else 'Potential vulnerability requiring validation',
                impact='Potential unauthorized privilege or information access; impact depends on the execution identity and effective permissions.' if severity != 'Informational' else 'Asset and test-context information.',
                validation_steps=validation, remediation=mitigation, related_findings=[], references=[], observed_at=now()))
    for f in findings:
        f['related_findings'] = [other['id'] for other in findings if other['id'] != f['id'] and other['source_section'] == f['source_section']][:12]
    if re.search(r'(?i)truncated|output cut off|interrupted', text):
        warnings.append('Evidence explicitly indicates incomplete or truncated collection')
    if not sections:
        warnings.append('No recognizable section headings; only explicit credential patterns were classified')
    if not findings:
        warnings.append('No rules matched; retained evidence is not a clean bill of health')
    return dict(tool=tool, findings=findings, warnings=warnings, sections=[redact(x) for x in sections], clean=redact(text))


def escape(value):
    return str(value).replace('|', '\\|').replace('\n', ' ').replace('<', '&lt;').replace('>', '&gt;').replace('[', '\\[').replace(']', '\\]').replace('!', '\\!')


def link(source, label, parent):
    relative = os.path.relpath(source, parent).replace(os.sep, '/')
    return '[' + escape(label) + '](<' + quote(relative, safe='/._-') + '>)'


def managed(path, body, title):
    original = path.read_text(encoding='utf-8') if path.exists() else '# ' + title + '\n\n'
    block = BEGIN + '\n' + body.rstrip() + '\n' + END
    if BEGIN in original or END in original:
        if original.count(BEGIN) != 1 or original.count(END) != 1 or original.index(BEGIN) > original.index(END):
            raise ValueError('Damaged generated markers; refusing to overwrite ' + str(path))
        first, rest = original.split(BEGIN, 1)
        _, last = rest.split(END, 1)
        text = first + block + last
    else:
        text = original + '\n\n' + block + '\n\n## Analyst notes\n\n'
    atomic(path, text)


def card(target, finding):
    path = target / 'reports' / 'peas' / (finding['id'] + '.md')
    if not path.exists():
        atomic(path, '# ' + finding['title'] + '\n\n**Severity:** ' + finding['severity'] + '\n\n**Validation:** ' + finding['validation_status'] + '\n\n**Classification:** ' + finding['classification'] + '\n\n## Analyst notes\n\n')
    content = path.read_text(encoding='utf-8')
    for field, key, allowed in [('Severity', 'severity', SEVERITIES), ('Validation', 'validation_status', STATES), ('Classification', 'classification', CLASSIFICATIONS)]:
        match = re.search(r'^\*\*' + field + r':\*\*\s*([^\r\n]+)', content, re.M)
        if match and match.group(1).strip() in allowed:
            finding[key] = match.group(1).strip()
    finding['classification'] = 'False positive or dismissed finding' if finding['validation_status'] == 'Dismissed' else finding['classification']
    transcript = target / 'evidence' / 'peas' / 'transcripts' / (finding['source_hash'] + '.md')
    body = '\n\n'.join([
        '**ID:** ' + finding['id'], '**Target / tool:** ' + finding['target'] + ' / ' + finding['source_tool'],
        '**Confidence:** ' + finding['confidence'], '**Original evidence SHA-256:** `' + finding['source_hash'] + '`', '**Original source reference:** ' + escape(finding.get('source_file', '')),  '**Classification:** ' + finding['classification'],
        '**Observation:** ' + escape(finding['description']), '**Evidence:** ' + link(transcript, 'Source lines ' + str(finding['line_start']), path.parent),
        '```text\n' + finding['evidence_excerpt'].replace('```', "'''") + '\n```',
        '**Potential impact:** ' + finding['impact'], '**Validation procedure:** ' + finding['validation_steps'],
        '**Mitigation:** ' + finding['remediation'], '**Observed:** ' + finding['observed_at'],
        '**Related:** ' + ', '.join('[[./' + ident + '|' + ident + ']]' for ident in finding['related_findings'])])
    managed(path, body, finding['title'])
    return path


def refresh_target(target):
    target = pathlib.Path(target).resolve()
    db_path = target / 'evidence/peas/parsed_findings.json'
    if not db_path.exists():
        (target / 'imports').mkdir(parents=True, exist_ok=True)
        return
    db = load(db_path, {})
    metadata = load(target / 'evidence/peas/imported_file_metadata.json', {})
    findings = db['findings']
    for finding in findings:
        card(target, finding)
    findings.sort(key=lambda f: (f['validation_status'] == 'Dismissed', SEVERITIES.index(f['severity']), f['id']))
    dump(db_path, db)
    report = target / 'reports/Privilege_Escalation_Findings.md'
    rows = ['## Local Enumeration & Privilege Escalation', '', 'Imported evidence is untrusted. Configuration indicators require validation; color alone is never a finding.', '']
    rows += ['**Severity totals:** ' + ', '.join(f'{severity}: {sum(f["severity"] == severity for f in findings)}' for severity in SEVERITIES), '']
    inventory = [f['evidence_excerpt'] for f in findings if f['category'] == 'host']
    rows += ['**Detected OS / build evidence:** ' + ('; '.join(inventory[:8]) or 'Not established by matched evidence'), '']
    for digest, item in metadata.items():
        rows.append('- ' + item['tool'] + ' imported ' + item['imported_at'] + '; SHA-256 `' + digest + '`; source ' + escape(', '.join(item['source_names'])))
        rows += ['  - Evidence warning: ' + escape(w) for w in item['warnings']]
    rows += ['', '| Severity | Finding | Confidence | Validation | Evidence |', '| --- | --- | --- | --- | --- |']
    for f in findings:
        page = target / 'reports/peas' / (f['id'] + '.md')
        rows.append('| ' + ' | '.join(map(escape, (f['severity'], f['title'], f['confidence'], f['validation_status']))) + ' | ' + link(page, f['id'], report.parent) + ' |')
    rows += ['', '## Recommended next validation steps', '']
    for f in [f for f in findings if f['validation_status'] not in ('Dismissed', 'Completed', 'Reviewed')][:10]:
        rows.append('- **' + f['id'] + ':** ' + f['validation_steps'])
    managed(report, '\n'.join(rows), 'Privilege Escalation Findings')
    dashboard = target / '00_TARGET_DASHBOARD.md'
    # Links must be relative to each report, not copied from the report table.
    dashboard_rows = '\n'.join(rows).replace('](<peas/', '](<reports/peas/')
    dashboard_rows += '\n\n' + link(report, 'Detailed privilege-escalation report', target) + '\n\n' + link(target / 'reports/PEAS_AI_Recommendations.md', 'Local AI next-test recommendations (check import console/status if pending)', target)
    managed(dashboard, dashboard_rows, 'Target Dashboard — ' + target.name)
    summary = target / 'reports/Target_Security_Report.md'
    managed(summary, '## Executive summary\n\nImported local enumeration produced ' + str(len(findings)) + ' recorded indicators, including ' + str(sum(f['severity'] in ('Critical', 'High') and f['validation_status'] != 'Dismissed' for f in findings)) + ' active high/critical indicators. These are not evidence of successful exploitation.\n\n' + link(report, 'Local enumeration findings', summary.parent) + '\n\n' + link(dashboard, 'Network and other target evidence', summary.parent), 'Target Security Report — ' + target.name)


def import_target(target, files=(), reprocess=False, model='qwen3.5:9b', ai=True, verbosity=10, log=print):
    target = pathlib.Path(target).resolve()
    target.mkdir(parents=True, exist_ok=True)
    imports = target / 'imports'
    contained(target, imports)
    imports.mkdir(exist_ok=True)
    if verbosity:
        log('[PEAS] Target: ' + target.name + ' | verbosity ' + str(verbosity))
    with target_lock(target):
        storage = target / 'evidence/peas'
        contained(target, storage)
        storage.mkdir(parents=True, exist_ok=True)
        for folder in (storage, target / 'reports', target / 'reports/peas'):
            contained(target, folder)
            folder.mkdir(parents=True, exist_ok=True)
        restricted = storage / '.restricted'
        contained(target, restricted)
        restricted.mkdir(exist_ok=True)
        protect(restricted)
        database_path, meta_path = storage / 'parsed_findings.json', storage / 'imported_file_metadata.json'
        database = load(database_path, dict(version=VERSION, findings=[]))
        metadata = load(meta_path, {})
        # External files are copied, never moved or executed. The name is content addressed.
        incoming_names = {}
        for filename in files:
            source = pathlib.Path(filename)
            if source.is_symlink() or not source.is_file() or source.suffix.lower() not in EXTENSIONS:
                raise ValueError('Expected a regular .txt/.log/.out/.ansi evidence file')
            if source.stat().st_size > 32 * 1024 * 1024:
                raise ValueError('Evidence exceeds 32 MiB import limit')
            data = source.read_bytes()
            digest = hashlib.sha256(data).hexdigest()
            dest = imports / (digest + source.suffix.lower())
            contained(target, dest)
            if not dest.exists():
                atomic(dest, data)
            # Snapshot names record source identity without allowing path traversal.
            names = metadata.get(digest, {}).get('source_names', [])
            incoming_names[digest] = names
            if source.name not in names:
                names.append(redact(source.name))
            if digest in metadata:
                metadata[digest]['source_names'] = names
        stats = dict(new=0, updated=0, duplicate=0, duplicate_files=0, validation_required=0, errors=0, imported_files=0)
        changed = False
        for source in sorted(imports.iterdir()):
            if source.suffix.lower() not in EXTENSIONS:
                continue
            try:
                contained(target, source)
                if not source.is_file() or source.stat().st_size > 32 * 1024 * 1024:
                    raise ValueError('Invalid or oversized evidence file')
                before = source.stat()
                data = source.read_bytes()
                after = source.stat()
                if (before.st_mtime_ns, before.st_size) != (after.st_mtime_ns, after.st_size):
                    raise ValueError('File changed during reading; retry when copy completes')
                digest = hashlib.sha256(data).hexdigest()
                if digest in metadata and not reprocess:
                    stats['duplicate_files'] += 1
                    stats['duplicate'] += sum(f['source_hash'] == digest for f in database['findings'])
                    if verbosity >= 10:
                        log('[PEAS] Duplicate hash ' + digest + '; preserving existing findings and analyst overrides')
                    continue
                parsed = parse(data, target.name, digest)
                if verbosity >= 10:
                    log('[PEAS] SHA-256 ' + digest + ' | source bytes ' + str(len(data)) + ' | parser version ' + str(VERSION))
                    for warning in parsed['warnings']:
                        log('[PEAS WARNING] ' + warning)
                if verbosity >= 5:
                    log('[PEAS] ' + parsed['tool'] + ' detected: ' + source.name + ' | normalizing and correlating ' + str(len(parsed['findings'])) + ' indicators')
                snapshot = restricted / digest
                if not snapshot.exists():
                    atomic(snapshot, data)
                elif hashlib.sha256(snapshot.read_bytes()).hexdigest() != digest:
                    raise ValueError('Protected snapshot hash mismatch')
                protect(snapshot)
                transcripts = storage / 'transcripts'
                contained(target, transcripts)
                transcripts.mkdir(exist_ok=True)
                transcript = '# Redacted evidence transcript\n\nOriginal SHA-256: `' + digest + '`\n\n'
                fence = '`' * max(3, 1 + max((len(m.group()) for m in re.finditer(r'`+', parsed['clean'])), default=0))
                transcript += fence + 'text\n' + '\n'.join(str(i) + ': ' + line for i, line in enumerate(parsed['clean'].splitlines(), 1)) + '\n' + fence + '\n'
                atomic(transcripts / (digest + '.md'), transcript)
                old_ids = {f['id'] for f in database['findings']}
                for f in parsed['findings']:
                    f['original_evidence_file'] = snapshot.relative_to(target).as_posix()
                    f['original_evidence_sha256'] = digest
                    f['source_file'] = source.relative_to(target).as_posix()
                    f['transcript'] = (transcripts / (digest + '.md')).relative_to(target).as_posix()
                    stats['updated' if f['id'] in old_ids else 'new'] += 1
                    stats['validation_required'] += f['validation_status'] == 'Needs Action'
                # Same hash keeps stable IDs; analyst overrides are reloaded from cards.
                previous = {f['id']: f for f in database['findings']}
                for f in parsed['findings']:
                    if f['id'] in previous:
                        f['observed_at'] = previous[f['id']]['observed_at']
                    previous[f['id']] = f
                database['findings'] = list(previous.values())
                prior = metadata.get(digest, {})
                metadata[digest] = dict(tool=parsed['tool'], imported_at=prior.get('imported_at', now()), last_processed_at=now(), source_names=prior.get('source_names', incoming_names.get(digest, [redact(source.name)])), source_file=source.relative_to(target).as_posix(), warnings=parsed['warnings'], sha256=digest, parser_version=VERSION, size=len(data))
                changed = True
                stats['imported_files'] += 1
            except (OSError, ValueError) as exc:
                stats['errors'] += 1
                log('[PEAS ERROR] ' + redact(source.name) + ': ' + redact(str(exc)))
        dump(meta_path, metadata)
        dump(database_path, database)
        refresh_target(target)
        if verbosity >= 10:
            log('[PEAS] Structured evidence saved; dashboard, finding cards, executive summary and detailed report refreshed at ' + str(target))
        if changed and ai:
            if verbosity:
                log('[PEAS] Correlating with network evidence using local model ' + model)
            try:
                from ai_advisor import ask_ollama
                ranked = sorted(database['findings'], key=lambda f:(f['validation_status'] == 'Dismissed', SEVERITIES.index(f['severity'])))
                facts = 'FILE: ../evidence/peas/parsed_findings.json\n' + json.dumps(dict(findings=ranked[:30], total_findings=len(ranked), selection='Top 30 severity-ranked indicators; not exhaustive'))[:28000]
                # Correlate with bounded network evidence; skip unredacted originals and model output.
                for source in sorted(target.rglob('*.nmap'), key=lambda p:p.stat().st_mtime, reverse=True)[:3]:
                    contained(target, source)
                    facts += '\nFILE: ' + source.relative_to(target).as_posix() + '\n' + redact(source.read_text(encoding='utf-8', errors='replace')[:8000])
                response = ask_ollama(model, 'Write for reports/PEAS_AI_Recommendations.md, using ../evidence/peas/transcripts/HASH.md and peas/ID.md as evidence links. Correlate imported local enumeration with network evidence. For each next validation recommendation include purpose, procedure, expected outcome, priority, status, supporting evidence and analyst observations. Treat hypotheses as unvalidated. Never reuse credentials.', facts[:44000])
                managed(target / 'reports/PEAS_AI_Recommendations.md', redact(response), 'PEAS AI Recommendations')
                atomic(storage / 'ai_status.json', json.dumps(dict(state='Completed', model=model, timestamp=now())))
                log('[PEAS] Local AI recommendations refreshed')
            except Exception as exc:
                dump(storage / 'ai_status.json', dict(state='Needs Action', error=redact(str(exc)), timestamp=now()))
                log('[PEAS] Import preserved; local AI unavailable: ' + redact(str(exc)))
        elif changed:
            dump(storage / 'ai_status.json', dict(state='Needs Action', reason='AI explicitly disabled', timestamp=now()))
        if verbosity:
            log('[PEAS] Import complete: ' + ', '.join(str(v) + ' ' + k for k, v in stats.items()))
        return stats


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('target', help='IPv4 address or hostname (one target, no CIDR)')
    parser.add_argument('mode', nargs='?', default='Import', choices=['Import', 'import'])
    parser.add_argument('--file', action='append', default=[])
    parser.add_argument('--output', type=pathlib.Path, help='Existing serialized session evidence directory')
    parser.add_argument('--reprocess', action='store_true')
    parser.add_argument('--no-ai', action='store_true')
    parser.add_argument('--model', default='qwen3.5:9b')
    parser.add_argument('--verbosity', type=int, choices=range(0,11), default=10)
    parser.add_argument('--render-only', action='store_true')
    args = parser.parse_args(argv)
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,252}', args.target) or args.target in ('.', '..'):
        parser.error('Unsafe target name')
    if not args.output:
        import session_manager as sm
        session = sm.get_active_session() or sm.create_session('Local Enumeration')
        args.output = session['path']
    output = args.output.resolve()
    target = output / args.target
    contained(output, target)
    if args.render_only:
        refresh_target(target)
        return 0
    stats = import_target(target, args.file, args.reprocess, args.model, not args.no_ai, args.verbosity)
    if (output / 'session_manifest.json').exists():
        import session_manager as sm
        sm.build_session_enumeration_report(output)
    return 1 if stats['errors'] else 0

if __name__ == '__main__':
    raise SystemExit(main())
