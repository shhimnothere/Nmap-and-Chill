# Nmap Obsidian Suite — local enumeration evidence imports

The existing Quick, Basic, UDP, Full, Vulns, Recon, All and Dashboard modes remain available. **Import** is an offline evidence workflow: it does not run Nmap, run PEASS, or execute any command found in an evidence file.

## Save an authorized PEASS collection

Run a trusted PEASS-ng version yourself on the authorized test system and capture its output. Example collection commands, to run manually in the approved context:

```bash
bash ./linpeas.sh 2>&1 | tee linpeas_results.txt
```

```powershell
.\winPEASx64.exe 2>&1 | Tee-Object -FilePath winpeas_results.txt
```

Use UTF-8 text when exporting from Windows PowerShell. The importer supports `.txt`, `.log`, `.out` and `.ansi`, up to 32 MiB per file. It detects LinPEAS/WinPEAS from the content, not the filename. Original bytes and ANSI coloring are retained in the protected snapshot; a separate redacted, line-numbered transcript supports review.

## Desktop workflow

1. Restart the dashboard after installing this update. Continue or create a serialized session and select one IPv4 target.
2. Click **Import LinPEAS / WinPEAS…** to select one or more output files, or click **Open Target Imports** and copy output into that folder.
3. With **Watch imports** enabled, the selected target's folder is checked every 10 seconds. A file must have identical size/mtime on two consecutive checks before it is processed. This is a polling watcher for the selected target while the dashboard is open. Avoid dropping a file until collection/copy has finished; an unusually long paused copy can still appear stable.
4. **Refresh Dropped PEAS Files** is the reliable manual fallback. It does not require a new network scan.
5. Open the session in Obsidian. The target dashboard contains **Local Enumeration & Privilege Escalation**, report links, OS observations, severity totals, evidence warnings, and the prioritized finding table.

The folder is inside the active serialized session:

```text
scans/sessions/CTP-LOCAL-DATE-TIME_Name/TARGET/
  imports/                              # unchanged import copies / user drops
  evidence/peas/
    imported_file_metadata.json         # hashes, tool, timestamps, source names, warnings
    parsed_findings.json                # normalized, redacted findings
    transcripts/HASH.md                 # redacted numbered transcript
    .restricted/HASH                    # immutable exact-byte snapshot
    ai_status.json                      # AI success, disabled, or retry-needed state
  reports/
    Privilege_Escalation_Findings.md     # aggregate report
    Target_Security_Report.md           # executive summary and network report links
    PEAS_AI_Recommendations.md          # local AI correlation and next test steps
    peas/PEAS-ID.md                     # persistent per-finding analyst card
  00_TARGET_DASHBOARD.md
  Runs/                                 # existing scan directories, unchanged
```

Hashes identify duplicate content even under a different filename. Finding IDs use target, content hash, category and line number. Different captures remain separate historical observations, including captures from different users; do not assume one import supersedes another. The tool cannot infer collection time or execution privilege reliably unless present in evidence. Metadata records import time; quoted context retains the observed user.

## CLI import and manual refresh (Kali or WSL)

Use the actual script filename in this repository:

```bash
bash ./NmapAutomator_Kali_Obsidian_Dashboard_v6_2.sh 192.0.2.150 Import \
  --file /path/to/linpeas_results.txt \
  --file /path/to/winpeas_results.log \
  --output /path/to/scans/sessions/CTP-YOUR_SESSION
```

`--output` is the session directory, not the target subdirectory. If omitted, the active serialized session is used (or a new Local Enumeration session is created). Import can accept a safe hostname through the CLI; the desktop target control remains IPv4-only. Existing network scanning remains IPv4-only.

Refresh files already in the target's `imports/` directory:

```bash
python3 peas_import.py 192.0.2.150 Import --output /path/to/SESSION
```

Reprocess with the current parser while preserving analyst overrides:

```bash
python3 peas_import.py 192.0.2.150 Import --output /path/to/SESSION --reprocess
```

Choose the local model or explicitly skip it:

```bash
python3 peas_import.py 192.0.2.150 Import --output /path/to/SESSION --model qwen3.5:9b
python3 peas_import.py 192.0.2.150 Import --output /path/to/SESSION --no-ai
```

Verbosity defaults to **10**; use `--verbosity 0..10` for less logging. Error counts and validation-required counts are real parser results, not model estimates. An empty, unknown or malformed file is reported as an error and is not marked successfully imported. Errors in one dropped file do not discard successful imports. Reprocess successful evidence to retry AI after an outage. `ai_status.json` records failures; deterministic reports remain available.

## Validation and analyst edits

Each finding has a persistent card under `reports/peas/`. Edit **Severity**, **Validation**, and **Classification** outside the generated block. Classification supports Confirmed configuration weakness, Potential vulnerability requiring validation, Informational discovery, and False positive or dismissed finding. Only assign confirmed classification after recording supporting validation evidence. Validation supports `Needs Action`, `In Progress`, `Completed`, `Dismissed`, and `Reviewed`. These overrides and analyst notes survive duplicate imports, reprocessing and report refreshes. `Completed` means the analyst finished the task; it does not by itself confirm exploitation. Record validated configuration weaknesses, false positives and retest outcomes in the notes.

The dashboard/aggregate reports update from those cards on the next Import refresh or Dashboard rebuild. Edit only outside `BEGIN PEAS GENERATED` / `END PEAS GENERATED` blocks for text that must persist. Existing Nmap/SNMP/web sections and `01_FINDINGS.md` are preserved; imported PEAS evidence is also included in the session report and evidence hashes. Existing AI findings generation reads the redacted structured PEAS records, and imports generate a separate local AI correlation report.

## Evidence safety and parser limits

- Imported files and embedded commands are never executed. All model calls use the local Ollama endpoint; there is no external AI upload path.
- Password/token assignments, CLI secret flags, authenticated URLs, authorization headers, private key blocks and common hash-dump formats are redacted in transcripts, structured findings and model inputs. Redaction is pattern-based: review unfamiliar secret formats before sharing reports.
- Original snapshots are in a hidden `.restricted` folder with POSIX owner-only permissions or a Windows owner/SYSTEM ACL. WSL on Windows-mounted drives uses Windows ACLs when interop is available. This restricts other accounts; it is not encryption or protection from administrators. User-supplied source files and `imports/` remain the tester's responsibility and are excluded from AI evidence collection.
- The parser recognizes section headings and specific configuration lines. It covers host/user context, sudo/SUID/capabilities, writable/scheduled execution paths, services/processes, secrets, environment/PATH, version indicators, containers/NFS, Windows tokens/UAC, service ACLs, unquoted paths, tasks, registry policies, credentials, DLL paths and security products. It is conservative and does not guarantee support for every PEASS-ng format or language. Raw retained evidence supports manual review of unmatched sections.
- Colors and suggested CVEs alone never establish a vulnerability. Findings default to potential or informational observations. Unknown headers, missing completion markers, invalid encoding and signs of truncation are reported; absence of matched findings does not establish a secure host.
- A `.peas.lock` directory prevents simultaneous imports to one target. If an importer is killed, verify it is no longer running before removing the stale lock. Avoid concurrent scanner/CLI writes to the same target; the GUI serializes its own tasks.
- Original evidence is immutable after snapshot creation; a new capture creates a new hash. No automatic privilege escalation or credential reuse is performed.

## Tests

```bash
python3 tests/test_peas_import.py
python3 tests/test_ai_advisor.py
python3 tests/test_ai_findings.py
python3 tests/security_qa_regression.py
```

The PEAS test module includes synthetic Linux/Windows fixtures, ANSI/version variation, truncation/empty-file handling, deduplication, similar finding names, secret handling, analyst override preservation, report regeneration, AI outage handling and offline CLI import. Security regression tests use dry runs and synthetic evidence rather than live scans.


## Evidence-aware test advisor

The advisor now requires one evidence target and constructs its test history before consulting the model. A successful full TCP scan is recognized from target-matched Nmap XML with successful completion and all 65,535 TCP ports in scaninfo, not from the action queue or the presence of an excerpt. Narrow, failed, interrupted, dry-run and mismatched-target evidence do not establish full coverage. Existing successful measurements are retained when a later attempt fails.

Recon collection results and analyst review are separate: an unchecked manual review does not mean its HTTP/SSH/SNMP acquisition was never performed. Checked Completed action notes are respected independently of scan proof. Manually saved SNMP OID output is recognized under the selected target; a recorded command with public plus returned OID values is distinguished from a service banner. Evidence under another target folder is excluded and is never silently reassigned.

The model receives a preselected remaining-task list and returns explanations against exact task IDs. Missing, duplicate, unsupported and contradictory recommendations are rejected and retried once. A failed or unavailable model leaves the deterministic plan available. Advisor drafts are saved under the selected target so evidence links resolve. Imported PEAS files mistakenly placed under 127.0.0.1 stay there until the tester deliberately imports the correct source under the intended target; the tool does not guess their identity.

Run `python3 tests/test_advisor_history.py` for completion-history regressions.
